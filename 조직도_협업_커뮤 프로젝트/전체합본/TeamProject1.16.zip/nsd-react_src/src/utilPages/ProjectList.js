import './utilPages.css';
import {useEffect, useState} from 'react'
import EmployeeInformation from './EmployeeInformation';
import axios from 'axios';

function ProjectList({pjData, projectDelete, loginRank, onExclude, newIssue, issueList}){    // 프로젝트 리스트와 참여 인원 리스트 컴포넌트

    const [isIssue, setIsIssue] = useState(false);

    useEffect(() => {
        axiosIssueCheck(pjData.no);
    }, []);

    function axiosIssueCheck(pjNo){
        axios.get(`http://localhost:8080/spring/company/issueCheck?pjNo=${pjNo}`)
        .then(response => {
                setIsIssue(response.data);
            })
            .catch(error => {
                console.error('에러!', error);
    })
    }

    return(
        <div>
            <fieldset>
                <legend>
                    {pjData.project_name} - {pjData.project_content} - {pjData.project_period} &nbsp;
                    {<button onClick={()=>newIssue(pjData.no)}>이슈 등록</button>}
                    {isIssue && <button onClick={()=>issueList(pjData.no)}>이슈 리스트</button>}
                    {/* 프로젝트 이름값을 추가로 넘겨주게 변경 */}
                    {loginRank<=0 && <button onClick={()=>projectDelete(pjData.no, pjData.project_name)}>프로젝트 종료</button>}
                </legend>
                <div id='project_member_area'>
                    {pjData.employee.map((e,i)=>
                        <EmployeeInformation key={i} name={e.name} position={e.position} xxx={() => onExclude(pjData.no,e.company_id)}/>
                    )}
                </div>
            </fieldset>
        </div>
    );
}

export default ProjectList;
