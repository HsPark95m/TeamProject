package com.project.listener;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import com.project.controller.PjController;

@WebListener
public class SessionListener implements HttpSessionListener {
    @Override
    public void sessionDestroyed(HttpSessionEvent se) {
        HttpSession session = se.getSession();
        String userId = (String) session.getAttribute("loginId");
        if (userId != null) {
            PjController.loggedInUsers.remove(userId);
        }
    }

    @Override
    public void sessionCreated(HttpSessionEvent se) {
        // 세션 생성 시 필요한 로직이 있다면 여기에 구현
    }
}
