package com.emma.spring.orgc.service;

import java.util.ArrayList;

import com.emma.spring.orgc.dto.EmpDto;

public interface EmpService {
	public ArrayList<EmpDto> getEmp();

	public int divCount();
}
