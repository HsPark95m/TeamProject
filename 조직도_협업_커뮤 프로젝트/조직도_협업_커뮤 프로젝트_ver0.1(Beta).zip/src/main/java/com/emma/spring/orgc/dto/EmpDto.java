package com.emma.spring.orgc.dto;

import lombok.Data;

@Data
public class EmpDto {
	private Long Emp_no;
	private String Emp_name;
	private String Emp_dep;
	private String Emp_position;
	private Long Emp_rank;
}
