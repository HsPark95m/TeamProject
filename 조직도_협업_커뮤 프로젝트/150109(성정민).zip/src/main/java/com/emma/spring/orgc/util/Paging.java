package com.emma.spring.orgc.util;

import java.util.ArrayList;

import com.emma.spring.orgc.dto.BoardPostDto;
import com.emma.spring.orgc.mapper.BoardMapper;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Paging {
    private int pageSize; //페이지당 보여지는 게시글 최대 개수
    
    int page;  //현재 페이지
    int block; //현재 블럭
    
    int totalListCnt;    //총 게시글 수
    int totalPageCnt;    //총 페이지 수
    int totalBlockCnt;   //총 구간 수

    int startPage;    //시작 페이지
    int endPage;     //마지막 페이지

    int prevPage;     // 이전 구간 마지막 페이지
    int nextPage;    // 다음 구간 시작 페이지

    int startIndex;     // 인덱스


    public Paging(Integer totalListCnt, Integer page, Integer pageSize, Integer blockSize) {
        this.pageSize = pageSize;

        this.page = page;        
        this.totalListCnt = totalListCnt;
        totalPageCnt = (int) Math.ceil(totalListCnt * 1.0 / this.pageSize);
        totalBlockCnt = (int) Math.ceil(totalPageCnt * 1.0 / blockSize);
        block = (int) Math.ceil((this.page * 1.0) / blockSize);
        if(block < 1) block = 1;

        startPage = ((block - 1) * blockSize + 1);
        endPage = startPage + blockSize - 1;
        if (endPage > totalPageCnt) endPage = totalPageCnt;

        prevPage = (block * blockSize) - blockSize;
        if (prevPage < 1) prevPage = 1;

        nextPage = (block * blockSize + 1);

        if (nextPage > totalPageCnt) nextPage = totalPageCnt;

        //if(this.page < 1) this.page = 1

        startIndex = (this.page - 1) * this.pageSize;
    }
} 

// 이 클래스 자체를 react로 넘겨서 페이징처리를 react에서 하는듯? 하는법 연구해보기