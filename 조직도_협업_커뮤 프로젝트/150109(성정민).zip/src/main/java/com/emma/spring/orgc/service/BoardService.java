package com.emma.spring.orgc.service;

import java.util.List;
import com.emma.spring.orgc.util.*;
import com.emma.spring.orgc.dto.BoardPostDto;

public interface BoardService {
	public List<BoardPostDto> getList(int currentPage);
//	public BoardListProcessor getList(int currentPage);
//	public BoardListProcessor getList(int currentPage, String word, String cp, String type);
//	public BoardPostDto read(long postId);
//	public void del(long postId);
//	public void write(BoardPostDto dto);
//	public void modify(BoardPostDto dto);
////	public void increaseViewCount(long postId);
//	public void restore(long postId); //단일 복구
//	public void restore(List<Long> postIds); //다중 복구
	//git 테스트
}
