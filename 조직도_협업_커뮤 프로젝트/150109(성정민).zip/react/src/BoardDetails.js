import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import BoardContent from "./BoardContent.js";

function BoardDetails() {
  const { postId } = useParams();
  const [loading, setLoading] = useState(true);
  const [board, setBoard] = useState({});
  // const getBoard = async () => {
  //   const resp = await (await axios.get(`http://localhost:8080/board/${postId}`)).data;
  //   setBoard(resp.data);
  //   setLoading(false);
  // };
  const getBoard = async () => {
    try {
      const response = await axios.get(`http://localhost:8080/orgc/board/${postId}`);
      setBoard(response.data);
      console.log(board);
      setLoading(false);
    }  catch (error) {
      console.error("data fetching error:", error);
    }
  }
  
  useEffect(() => {
    getBoard();
  }, []);

  return (
    <div>
      {loading ? (
        <h2>loading...</h2>
      ) : (
        <BoardContent
          postId={board.postId}
          title={board.title}
          contents={board.contents}
          createdBy={board.createdBy}
        />
      )}
    </div>
  );
};

export default BoardDetails;