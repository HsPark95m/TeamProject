import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Home.css';

function Login() {
    const [no, setNo] = useState(""); // Emp_no 입력 상태
    const [pw, setPw] = useState(""); // Emp_pw 입력 상태
    const [message, setMessage] = useState(""); // 서버 응답 메시지
    const [islogin, setisLogin] = useState(false);
  
    const handleSubmit = async (event) => {
      event.preventDefault();
  
      try {
        // 서버에 POST 요청
        const response = await axios.post("http://localhost:8080/orgc/emp/login", {
          Emp_no: no,
          Emp_pw: pw,
        });
  
        // 서버에서 반환된 메시지 설정
        setMessage(response.data);
  
  
        // 로그인 성공 처리 (예: 홈 화면으로 이동)
        if (response.data === "success") {
          // 리다이렉션 또는 상태 업데이트
          alert("로그인 성공!");
          setisLogin(true);
          // key = "no" value 사번으로 세션에 값 저장
          sessionStorage.setItem("no", no);
          // 홈페이지 이동
          document.location.href="/orgc";
        } else {
          alert("로그인 실패. 다시 시도하세요.");
        }
      } catch (error) {
        console.error("로그인 중 오류 발생:", error);
        setMessage("서버와의 연결에 문제가 발생했습니다.");
      }
    };
  
    return (
      <div style={{ maxWidth: "400px", margin: "0 auto", textAlign: "center" }}>
        <h2>로그인</h2>
        <form onSubmit={handleSubmit}>
          <div>
            <label>사번 (no):</label>
            <input
              type="text"
              value={no}
              onChange={(e) => setNo(e.target.value)}
              required
            />
          </div>
          <div>
            <label>비밀번호 (pw):</label>
            <input
              type="password"
              value={pw}
              onChange={(e) => setPw(e.target.value)}
              required
            />
          </div>
          <button type="submit">로그인</button>
        </form>
        {/* 서버 응답 메시지 표시 */}
        {message && <p>{message}</p>}
      </div>
    );
  }
  
function Home() {

    return(
    <div style={{ maxWidth: "400px", margin: "0 auto", textAlign: "center" }}>

        <h1>OO회사 사내망</h1>
        <Login/>
        
    </div>
    )
}

export default Home;