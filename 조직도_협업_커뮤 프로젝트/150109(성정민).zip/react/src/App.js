import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import './App.css';
import Home from './Home';
import Orgc from './Orgc';
import History from './History';
import CoopPj from './CoopPj';
import Board from './Board';
import BoardDetails from './BoardDetails';

function App() {
  const [isLogin, setIsLogin] = useState(false);

  useEffect(() => {
    // 로그인 상태를 sessionStorage로 관리
    if (sessionStorage.getItem("no") === null) {
      setIsLogin(false);
    } else {
      setIsLogin(true);
    }
  }, []);

  return (
    <BrowserRouter>
      <Routes>
        {/* 로그인 여부에 따라 라우팅 처리 */}
        {isLogin ? (
          <>
            <Route path="/" element={<Home />} />
            <Route path="/orgc" element={<Orgc />} />
                <Route path="/hist" element={<History />} />
                <Route path="/copj" element={<CoopPj />} />
            <Route path="/board" element={<Board />} />
            <Route path="/board/:postId" element={<BoardDetails />} />
          </>
        ) : (
          <Route path="/*" element={<Home />} />
        )}
      </Routes>
    </BrowserRouter>
  );
}

export default App;
