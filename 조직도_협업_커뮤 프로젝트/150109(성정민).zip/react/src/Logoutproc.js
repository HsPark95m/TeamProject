
function Logoutproc() {
  sessionStorage.clear();
  alert("로그아웃 되었습니다!");
  document.location.replace("/");
}

export default Logoutproc;