import axios from 'axios';
import React, { useState, useEffect } from 'react';
import './Orgc.css';
import Clock from './Clock.js';
import { Link } from 'react-router';
import Logoutproc from './Logoutproc.js';

//todo 1. rank or dep별로 사원추출하는 api제작
//     2. 그룹별 사원 담을 그릇만들 useState제작

function Orgc() {
  // eslint-disable-next-line
  var [emp,setEmp] = useState([]);

  useEffect(() => {	
    
    return () => {
    };
  }, []);
  // eslint-disable-next-line
  function commonGetApi(url,setter){
    axios.get(url)			
    .then(response => setter(response.data) )		
    .catch(error => console.error('에러:', error) );
  }
  /*div반복생성관련 확인링크
  https://seoyun-is-connecting-the-dots.tistory.com/322
  */
  if(sessionStorage.getItem("no")==='0000'){
    return (
    <>
      <Clock />
      <div style={{float: "right"}}>
          <button style={{height: "30px"}} onClick={() => Logoutproc()}>로그아웃</button>
        </div>
      <button disabled>조직도페이지</button><Link to="/hist"><button>연혁</button></Link>
      <Link to="/copj"><button>협업프로젝트</button></Link><Link to="/board"><button>사내게시판</button></Link>
      <div id='orgc_area'>
        <div className='dep_0_area'>
            <div className='dep_0'>사장(rank0) {"\n"} 자리</div>
        </div>
        <div className='dep_1_area'>
            <div className='dep_1'>부서1이름</div>
        </div>
        <div className='dep_2_area'>
            <div className='dep_2'>부서2이름</div>
         </div>
         <div className='dep_3_area'>
            <div className='dep_3'>부서3이름</div>
         </div>
       </div>
     </>
   );
  }else{
    return (
      <>
        <Clock />
        <div style={{float: "right"}}>
          <button style={{height: "30px"}} onClick={() => Logoutproc()}>로그아웃</button>
        </div>
        <button disabled>조직도페이지</button><Link to="/hist"><button>연혁</button></Link>
        <Link to="/copj"><button>협업프로젝트</button></Link><Link to="/board"><button>사내게시판</button></Link>
        <div id='orgc_area'>
          <div className='dep_0_area'>
             <div className='dep_0'>사장(rank0) {"\n"} 자리</div>
          </div>
          <div className='dep_1_area'>
             <div className='dep_1'>부서1이름</div>
          </div>
          <div className='dep_2_area'>
             <div className='dep_2'>부서2이름</div>
          </div>
          <div className='dep_3_area'>
             <div className='dep_3'>부서3이름</div>
          </div>
        </div>
      </>
    );
  } 
}

export default Orgc;