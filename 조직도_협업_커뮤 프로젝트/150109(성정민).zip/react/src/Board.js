import axios from 'axios';
import React, { useState, useEffect } from 'react';
import './Board.css';
import Clock from './Clock.js';
import { Link, Route, Routes } from "react-router-dom";
import Logoutproc from './Logoutproc.js';


function Board({}) {
  const [boardList, setBoardList] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:8080/orgc/board/getList')
      .then(response => {
        setBoardList(response.data); // Fixed: Removed incorrect spreading
      })
      .catch(error => {
        console.error('Error fetching data: ', error);
      });
  }, []);

  function BoardArea() {
    return (
      <div id="board_area">
        <ul>
          {boardList.map((board) =>
            <li key={board.postId}>
              <Link to={`/board/${board.postId}`}>{board.title}</Link>
            </li>
          )}
        </ul>
      </div>
    );
  }

  if (sessionStorage.getItem("no") === '0000') {
    return (
      <>
        <Clock />
        <div style={{float: "right"}}>
          <button style={{height: "30px"}} onClick={() => Logoutproc()}>로그아웃</button>
        </div>
        <Link to="/orgc"><button>조직도페이지</button></Link><Link to="/hist"><button>연혁</button></Link><Link to="/copj"><button>협업프로젝트</button></Link>
        <button disabled>사내게시판</button>
        <BoardArea/>
      </>
    );
  } else {
    return (
      <>
        <Clock />
        <div style={{float: "right"}}>
          <button style={{height: "30px"}} onClick={() => Logoutproc()}>로그아웃</button>
        </div>
        <Link to="/orgc"><button>조직도페이지</button></Link><Link to="/hist"><button>연혁</button></Link><Link to="/copj"><button>협업프로젝트</button></Link>
        <button disabled>사내게시판</button>
        <BoardArea/>
      </>
    );
  }
}

export default Board;