import React from 'react';

const BoardContent = ({ postId, title, contents, createdBy }) => {
  return (
    <div>
      <h2>{title}</h2> 
      <p>{postId}</p>
      <h5>{createdBy}</h5>
      <hr />
      <p>{contents}</p>
    </div>
  );
};

export default BoardContent;