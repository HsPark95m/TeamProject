
import React, { useState, useEffect } from 'react';
import './History.css';
import Clock from './Clock.js';
import { Link } from 'react-router';
import Logoutproc from './Logoutproc.js';

function History({}) {
  /* 협업페이지내 추가페이지 확장성 대비 남김 */
  // var [currentPage,setCurrentPage] = useState(PAGE.GAME_CITY);
  // const game_cinematic = () => setCurrentPage(PAGE.GAME_CINEMATIC);
  // const game_land = () => setCurrentPage(PAGE.GAME_LAND);

  function HistoryArea({ }) {

    return (
      <>

          <div id='history_area'>
            대충 회사 연혁
          </div>

        </>
    );

  }
  if(sessionStorage.getItem("no")==='0000'){
    return (
      <>
        <Clock />
        <div style={{float: "right"}}>
          <button style={{height: "30px"}} onClick={() => Logoutproc()}>로그아웃</button>
        </div>
        <Link to="/orgc"><button>조직도페이지</button></Link><button disabled>연혁</button>
        <Link to="/copj"><button>협업프로젝트</button></Link><Link to="/board"><button>사내게시판</button></Link>
        <HistoryArea></HistoryArea>
  
      </>
    );    
  }else{
    return (
      <>
        <Clock />
        <div style={{float: "right"}}>
          <button style={{height: "30px"}} onClick={() => Logoutproc()}>로그아웃</button>
        </div>
        <Link to="/orgc"><button>조직도페이지</button></Link><button disabled>연혁</button>
        <Link to="/copj"><button>협업프로젝트</button></Link><Link to="/board"><button>사내게시판</button></Link>
        <HistoryArea></HistoryArea>
  
      </>
    );
  }
}

export default History;