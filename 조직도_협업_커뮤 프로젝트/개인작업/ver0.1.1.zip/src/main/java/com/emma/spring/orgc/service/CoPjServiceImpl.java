package com.emma.spring.orgc.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emma.spring.orgc.dto.CoPjDto;
import com.emma.spring.orgc.dto.EmpDto;
import com.emma.spring.orgc.dto.MemberAddDto;
import com.emma.spring.orgc.mapper.CoPjMapper;
import com.emma.spring.orgc.mapper.EmpMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class CoPjServiceImpl implements CoPjService {
	@Setter(onMethod_ = @Autowired)
	private CoPjMapper mapper;

	@Setter(onMethod_ = @Autowired)
	private EmpMapper EmpMapper;

	@Override
	public ArrayList<CoPjDto> getCoPj() {
		ArrayList<CoPjDto> cpj = mapper.getCoPj();
		ArrayList<MemberAddDto> mem = mapper.getCoPjMember();
		ArrayList<EmpDto> emp = EmpMapper.getEmp();

		for (MemberAddDto e : mem) {
			for (CoPjDto c : cpj) {
				if (c.getCoop_no() == e.getCoop_no()) {
					for (EmpDto empdto : emp) {
						if (empdto.getEmp_no().equals(e.getEmp_no())) {
							c.employees.add(empdto);
						}
					}
					break;
				}
			}
		}

		return cpj;
	}

	@Override
	public void closeCoPj(Long pjNo) {
		mapper.closeCoPj(pjNo);
	}

	@Override
	public void pjMemberAdd(MemberAddDto m) {
		boolean isIn = true;

		ArrayList<MemberAddDto> searchM = mapper.getCoPjMember();
		for (MemberAddDto e : searchM) {
			if (e.getCoop_no() == m.getCoop_no()) {
				if (e.getEmp_no() == m.getEmp_no()) {
					isIn = false;
				}
			}
		}
		if (isIn) {
			mapper.pjMemberAdd(m);
		}
	}

	@Override
	public ArrayList<MemberAddDto> getCoPjMember() {
		return mapper.getCoPjMember();
	}
}
