package com.emma.spring.orgc.dto;

import java.util.ArrayList;

import lombok.Data;

@Data
public class CoPjDto {
	private Long Coop_no;
	private String Coop_name;
	private String Coop_content;
	private Long Coop_importance;
	public ArrayList<EmpDto> employees = new ArrayList<EmpDto>();
}
