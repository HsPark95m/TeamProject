package com.emma.spring.orgc.service;

import java.util.ArrayList;

import com.emma.spring.orgc.dto.EmpDto;
import com.emma.spring.orgc.dto.LoginDto;

public interface EmpService {
	public ArrayList<EmpDto> getEmp();

	public ArrayList<EmpDto> getEmpByRank(Long rank);

	public int divCount();

	public boolean login(LoginDto log);
}
