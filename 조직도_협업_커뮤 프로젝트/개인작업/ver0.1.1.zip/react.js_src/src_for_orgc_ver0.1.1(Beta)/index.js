import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter, Routes, Route } from 'react-router-dom'; // React Router 불러오기
import './index.css';

import Home from './Home.js'; // Home 페이지 불러오기
import Login from './login.js'; // Login 페이지 불러오기

const root = ReactDOM.createRoot(document.getElementById('root'));

root.render(
  <React.StrictMode>
    {/* BrowserRouter로 라우터 감싸기 */}
    <BrowserRouter>
      <Routes>
        {/* 기본 경로 "/"는 Home 컴포넌트를 렌더링 */}
        <Route path="/" element={<Home />} />
        {/* "/login" 경로는 Login 컴포넌트를 렌더링 */}
        <Route path="/login" element={<Login />} />
      </Routes>
    </BrowserRouter>
  </React.StrictMode>
);
