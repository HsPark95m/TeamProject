import React from 'react';
import './EmpInfo.css';

function EmpInfo({ x, y, copjList, employee, onClose }) {
  return (
    <div
      className="popup-menu"
      style={{
        top: y,
        left: x,
      }}
    >
      <p>이름: {employee.Emp_name}</p>
      <p>직급: {employee.Emp_position}</p>
      <p>부서: {employee.Emp_dep}</p>
      <button onClick={() => alert('상세 보기 클릭')}>사원정보상세보기</button>
      {/* pjList.map을 사용하여 pjList의 각 항목을 <option>으로 렌더링. */}
      {/* <select onChange={(e)=> alert(e.target.value)}> */}
      <select onChange={(e)=>onClose(employee.Emp_no, e.target.value)}>
        <option key='0' value='0'>대기</option>
        {copjList.map((pjData) => (
          <option key={pjData.Coop_no} value={pjData.Coop_no}>
            {pjData.Coop_no} - {pjData.Coop_name}
          </option>
        ))}
      </select>
      <button onClick={(e)=>onClose(0,0)}>닫기</button>
    </div>
  );
}

export default EmpInfo;
