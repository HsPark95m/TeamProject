import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom'; // useNavigate 임포트
import './Home.css';
import CoopPj from './CoopPj.js';
import Orgc from './Orgc.js';

function LoginLogout({ isLogin }) {
  const navigate = useNavigate(); // 페이지 이동 함수
  const [currentPage, setCurrentPage] = useState('orgc');

  function changeRootPage(page) {
    setCurrentPage(page);
  }

  if (isLogin) {
    return (
      <>
        <div style={{float: "right"}}>
          <button style={{height: "30px"}} onClick={() => navigate('/login')}>로그아웃 페이지로 이동</button>
        </div>
        <div>
          {currentPage === 'orgc' && <Orgc changeRootPage={changeRootPage} />}
          {currentPage === 'copj' && <CoopPj changeRootPage={changeRootPage} />}
        </div>  
      </>
    );
  } else {
    return (
      <>
        <div style={{float: "right"}}>
          <button style={{height: "30px"}} onClick={() => navigate('/login')}>로그인 페이지로 이동</button>
        </div>
        <div>
          {currentPage === 'orgc' && <Orgc changeRootPage={changeRootPage} />}
          {currentPage === 'copj' && <CoopPj changeRootPage={changeRootPage} />}
        </div>  
      </>
    );
  }
}

function Home() {
  const [islogin, setIsLogin] = useState(false);

  useEffect(() => {
    if (sessionStorage.getItem("no") === null) {
      setIsLogin(false);
    } else {
      setIsLogin(true);
    }
  }, [islogin]);

  return (
    <>
      {/* LoginLogout 컴포넌트에 로그인 상태 전달 */}
      <LoginLogout isLogin={islogin} />
    </>
  );
}

export default Home;
