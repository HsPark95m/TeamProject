import axios from 'axios';
import React, { useState, useEffect } from 'react';
import './ViewPj.css';
import Clock from './Clock.js';
import EmpInfo from './EmpInfo.js';

function ViewPj({changeRootPage}) {
  var [emp,setEmp] = useState([]);
  var [copjList,setCoPjList] = useState([]);
  var [popup, setPopup] = useState({ visible: false, x: 0, y: 0, emp: null });

  useEffect(() => {	
    getEmp();
    getCoPj();
    return () => {
    };
  }, []);

  function getEmp(){
    axios.get('http://localhost:8080/orgc/emp/getEmp')
    .then(response=>{
      setEmp(response.data);
    })
    .catch(error => console.error('에러:', error));
  }

  function getCoPj(){
    axios.get('http://localhost:8080/orgc/copj/getCoPj')
    .then(response=>{
      setCoPjList(response.data);
    })
    .catch(error => console.error('에러:', error));
  }

  function Emp({ name, position, department, info}) {
    return (
      <div className={`emp ${name} ${position} ${department}`} onClick={info}>
        {name}/{position}
      </div>
    );
  }

  function CoPjArea({ pjData, closePjListener }) {

    return (
      <>
        <fieldset>
          <legend>
            {pjData.Coop_no} {pjData.Coop_name} {pjData.Coop_content}
            &nbsp;&nbsp;<button onClick={()=>closePjListener(pjData.Coop_no)}>협업종료</button>
          </legend>
          <div id='emp_area'>
            {pjData.employees.map((employee,i)=>
              <Emp key={i} name={employee.Emp_name} position={employee.Emp_position} department={employee.Emp_dep}/>
            )}
          </div>
        </fieldset>    
      </>
    );
  }

  function closePj(pjNo){
    axios.get('http://localhost:8080/orgc/copj/closeCoPj?pjNo='+pjNo)	
    .then(() => {		
      getEmp();
      getCoPj();
    })		
    .catch(error => console.error('에러:', error) );
  }

  function handleEmpClick(e, emp) {
    const rect = e.target.getBoundingClientRect(); // 클릭한 컴포넌트의 좌표 객체를 얻는 함수. x,y 는좌상단. width,height 있음. top/right/bottom/left 있음
    setPopup({
      visible: true,
      x: rect.right + window.scrollX, // 스크롤 된 경우 스크롤 좌표 값까지 추가
      y: rect.top + window.scrollY,
      emp: emp,
    });
  }

  function closePopup(empNo, selectCoPj) { 
    if(empNo>=0 && selectCoPj>0){
      var d = {Emp_no: empNo, Coop_no: selectCoPj};
      pjMemberAdd(d);
    }
    setPopup({ visible: false, x: 0, y: 0, card: null });
  }

  function pjMemberAdd(d){
    axios.post('http://localhost:8080/orgc/copj/pjMemberAdd',d)			
    .then(() => {
      getEmp();
      getCoPj();
    })		
    .catch(error => console.error('에러:', error) );
  }

  if(sessionStorage.getItem("no")==='0000'){
    return (
      <>
        <Clock /><button onClick={()=>changeRootPage('orgc')}>조직도페이지</button><button disabled>협업페이지</button>
        <button style={{float: "right"}} onClick={()=>changeRootPage('adminE')}>사원관리</button>
        <button style={{float: "right"}} onClick={()=>changeRootPage('adminP')}>프로젝트관리</button>
        <button style={{float: "right"}} onClick={()=>changeRootPage('adminB')}>게시판관리</button>
        {copjList.map((d,i)=> <CoPjArea key={i} pjData={d} closePjListener={closePj} />)}
        <div id='emp_area'>
          {emp.map((employee, index) => (
            <Emp key={index} name={employee.Emp_name} position={employee.Emp_position} department={employee.Emp_dep} info={(e)=> handleEmpClick(e, employee)}/>
          ))}
        </div>
  
        {popup.visible && (
          <EmpInfo
            x={popup.x}
            y={popup.y}
            copjList={copjList}
            employee={popup.emp}
            onClose={closePopup}
          />
        )}
  
      </>
    );    
  }else{
    return (
      <>
        <Clock /><button onClick={()=>changeRootPage('orgc')}>조직도페이지</button><button disabled>협업페이지</button>
        {copjList.map((d,i)=> <CoPjArea key={i} pjData={d} closePjListener={closePj} />)}
        <div id='emp_area'>
          {emp.map((employee, index) => (
            <Emp key={index} name={employee.Emp_name} position={employee.Emp_position} department={employee.Emp_dep} info={(e)=> handleEmpClick(e, employee)}/>
          ))}
        </div>
  
        {popup.visible && (
          <EmpInfo
            x={popup.x}
            y={popup.y}
            copjList={copjList}
            employee={popup.emp}
            onClose={closePopup}
          />
        )}
  
      </>
    );
  }
}

export default CoopPj;