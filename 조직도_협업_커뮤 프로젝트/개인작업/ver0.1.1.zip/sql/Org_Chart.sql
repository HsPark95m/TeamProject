use my_cat;

show tables;

drop table Employee;
create table Employee(
	Emp_no char(4) primary key,
    Emp_name char(10) not null default '사원테스트',
    Emp_dep char(10) not null default '부서테스트',
    Emp_position char(10) not null default '부장',
    Emp_rank int not null default 1,
    Emp_pw char(15)
);

DELIMITER $$

CREATE TRIGGER set_pw_equal_to_no
BEFORE INSERT ON Employee
FOR EACH ROW
BEGIN
    IF NEW.Emp_pw IS NULL THEN
        SET NEW.Emp_pw = NEW.Emp_no;
    END IF;
END$$

DELIMITER ;

INSERT INTO Employee (`Emp_no`,`Emp_name`,`Emp_dep`,`Emp_position`,`Emp_rank`) VALUES ('0000','나사장','이사회','사장',0);
INSERT INTO Employee (`Emp_no`,`Emp_name`,`Emp_dep`,`Emp_position`,`Emp_rank`) VALUES ('0001','나부장','게임개발부','부장',1);
INSERT INTO Employee (`Emp_no`,`Emp_name`,`Emp_dep`,`Emp_position`,`Emp_rank`) VALUES ('0002','나사원','게임개발부','사원',2);
INSERT INTO Employee (`Emp_no`,`Emp_name`,`Emp_dep`,`Emp_position`,`Emp_rank`) VALUES ('0003','김부장','경영지원부','부장',1);
INSERT INTO Employee (`Emp_no`,`Emp_name`,`Emp_dep`,`Emp_position`,`Emp_rank`) VALUES ('0004','김사원','경영지원부','사원',2);
INSERT INTO Employee (`Emp_no`,`Emp_name`,`Emp_dep`,`Emp_position`,`Emp_rank`) VALUES ('0005','최사원','경영지원부','사원',2);
INSERT INTO Employee (`Emp_no`,`Emp_name`,`Emp_dep`,`Emp_position`,`Emp_rank`) VALUES ('0006','박사원','경영지원부','사원',2);
INSERT INTO Employee (`Emp_no`,`Emp_name`,`Emp_dep`,`Emp_position`,`Emp_rank`) VALUES ('0007','이부장','영업부','부장',1);
INSERT INTO Employee (`Emp_no`,`Emp_name`,`Emp_dep`,`Emp_position`,`Emp_rank`) VALUES ('0008','이사원','영업부','사원',2);
-- ALTER TABLE Employee DROP COLUMN Emp_participate;

select * from Employee where Emp_dep='영업부' order by Emp_rank asc;

update Employee set Emp_rank = 1 and Emp_position = '부장' where Emp_no = '0001';
update Employee set Emp_dep = '영업부' where Emp_no = '0008';

select * from Employee;
SELECT * from Employee ORDER BY Emp_rank;
SELECT * from Employee where Emp_rank=1 ORDER BY Emp_dep;
select count(*) from employee WHERE Emp_no LIKE '%0000%' AND Emp_pw LIKE '%0000%';

drop table Cooperation_Project;
create table Cooperation_Project(
	Coop_no int primary key,
	Coop_name char(20) not null default '무제',
    Coop_content char(255) not null default '설명란',
    Coop_importance int not null default 1
);
INSERT INTO Cooperation_Project (`Coop_no`, `Coop_name`) VALUES (1, '무제1');
INSERT INTO Cooperation_Project (`Coop_no`, `Coop_name`) VALUES (2, '무제2');
INSERT INTO Cooperation_Project (`Coop_no`, `Coop_name`) VALUES (3, '무제3');
select * from Cooperation_Project;

drop table Project_Management;
create table Project_Management(
	Emp_no int not null,
    Coop_no int not null
);
INSERT INTO Project_Management (`Emp_no`, `Coop_no`) VALUES (0, 1);
select * from Project_Management;