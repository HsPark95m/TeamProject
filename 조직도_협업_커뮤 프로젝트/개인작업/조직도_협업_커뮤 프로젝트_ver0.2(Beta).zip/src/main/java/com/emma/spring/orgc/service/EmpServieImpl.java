package com.emma.spring.orgc.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emma.spring.orgc.dto.DepDto;
import com.emma.spring.orgc.dto.EmpDto;
import com.emma.spring.orgc.dto.LoginDto;
import com.emma.spring.orgc.mapper.EmpMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class EmpServieImpl implements EmpService {
	@Setter(onMethod_ = @Autowired)
	private EmpMapper mapper;

	@Override
	public ArrayList<EmpDto> getEmp() {
		return mapper.getEmp();
	}

	@Override
	public ArrayList<EmpDto> getEmpByRank(Long rank) {
		return mapper.getEmpByRank(rank);
	}

	@Override
	public boolean login(LoginDto log) {
		boolean islogin = false;
		switch (mapper.login(log)) {
		case 0:
			islogin = false;
			break;
		case 1:
			islogin = true;
			break;
		}
		return islogin;
	}

	@Override
	public ArrayList<DepDto> getDep() {
		ArrayList<DepDto> dep = mapper.getDep();
		ArrayList<EmpDto> emp = mapper.getEmp();

		for (DepDto d : dep) {
			for (EmpDto e : emp) {
				if (d.getDep_name().equals(e.getEmp_dep())) {
					d.dep_mem.add(e);
				}
			}
		}

		return dep;
	}
}
