import { useState, useEffect } from 'react';
import './Pages.css';
import axios from 'axios';
import { useParams, useNavigate, Link } from 'react-router-dom';

function IssueRead() { //loginId 굳이 안넘어와도 될듯? 세션으로 그냥 꺼내면 됨 BoardRead.js 참조
    const { issueNo } = useParams(); // URL 파라미터에서 projectId 가져오기
    const issue_no = parseInt(issueNo, 10); // 숫자 변환
    const [issue, setIssue] = useState({ 
        issue_no: 0,
        issue_project_no: 0,
        issue_title: "",
        issue_details: "",
        issue_label: "",
        issue_author: "",
        issue_date: "",
        issue_is_closed: false,
        issue_closedDate: "",
        comments: []});
    const [comment, setComment] = useState('');
    const [editComment, setEditComment] = useState({
        comment_no: 0,
        comment_text: ''
    })
    const [loginName, setloginName] = useState('');
    
    useEffect(() => {
        handleLogin();
        axiosGetIssueByIssueNo();
    }, []);

    function handleLogin() {
        axios.get('http://localhost:8080/spring/company/loginInfo', { withCredentials: true })
        .then(response => {
            const loginInfo = response.data;
            setloginName(loginInfo.name);
        })
        .catch(error => {
            console.error('에러!', error);
        })
    }

    function axiosGetIssueByIssueNo() {
        axios.get(`http://localhost:8080/spring/company/getIssueByIssueNo?issueNo=${issue_no}`)
            .then((response) => {
                setIssue(response.data); 
            })
            .catch(error => {
                console.error('에러!', error);
            })
    }

    function axiosIssueClose(e) {
        e.preventDefault();
        if(window.confirm(`"${issue.issue_no}"번 이슈를 닫으시겠습니까?`)){
            axios.get(`http://localhost:8080/spring/company/issueClose?issueNo=${issue_no}`)
                .then(()=>{
                    alert('!!issue Closed!!')
                    axiosGetIssueByIssueNo();
                })
                .catch(error => {
                    console.error('에러!', error);
                })
            }
    }

    function axiosIssueReOpen(e) {
        e.preventDefault();
        if(window.confirm(`"${issue.issue_no}"번 이슈를 재오픈하시겠습니까?`)){
            axios.get(`http://localhost:8080/spring/company/issueReOpen?issueNo=${issue_no}`)
                .then(()=>{
                    alert('!!issue ReOpened!!')
                    axiosGetIssueByIssueNo();
                })
                .catch(error => {
                    console.error('에러!', error);
                })
            }
    }

    function commentModify(cData) {
        setEditComment({
            comment_no: cData.comment_no,
            comment_text: cData.comment_text
        });
    }

    function handleCancelEdit() {
        setEditComment({ comment_no: 0, comment_text: '' });
    }

    function handleSubmitEdit(e) {
        e.preventDefault();
        if (editComment.comment_text.trim() === '') {
            alert('댓글 내용은 비워둘 수 없습니다.');
            return;
        }
        axios.post('http://localhost:8080/spring/company/issueCommentModify', editComment)
            .then(() => {
                setEditComment({ comment_no: 0, comment_text: '' });
                axiosGetIssueByIssueNo();
            })
            .catch(error => {
                console.error('댓글 수정 실패:', error);
            });
    }

    function handleCommentSubmit(e) {
        e.preventDefault();
        if (comment.trim() === '') {
            alert('댓글 내용은 비워둘 수 없습니다.');
            return;
        }
        axios.post('http://localhost:8080/spring/company/issueCommentWrite', { comment_text: comment, comment_issue_no: issue_no, comment_author: loginName })
            .then(() => {
                setComment('');
                axiosGetIssueByIssueNo();
            })
            .catch(error => {
                console.error('댓글 등록 실패:', error);
            });
    }

    return (
        <div id="issue_read_page">
            <div id="Read_box">
                <h1>title: {issue.issue_title}</h1>
                #{issue.issue_no} {issue.issue_is_closed ? 'closed at' : 'opened at'} {issue.issue_is_closed ? issue.issue_closedDate : issue.issue_date} by {issue.issue_author}
                <h5>details: {issue.issue_details}</h5>
                <h2>comments</h2>
                {issue.comments.map((c, i) => (
                    <div className="issue_comment" key={i}>
                        <h4>{c.comment_text}</h4>
                        #{c.comment_no} commented by {c.comment_author} at {c.comment_date}
                        {c.comment_author === loginName && (
                            <button onClick={() => commentModify(c)}>댓글 수정</button>
                        )}
                    </div>
                ))}
                {editComment.comment_no > 0 && (
                    <form onSubmit={handleSubmitEdit}>
                        <textarea
                            style={{ width: '500px', height: '50px' }}
                            value={editComment.comment_text}
                            onChange={(e) =>
                                setEditComment((prev) => ({ ...prev, comment_text: e.target.value }))
                            }
                        />
                        <br />
                        <button type="submit">수정 댓글 등록</button>
                        <button type="button" onClick={handleCancelEdit}>취소</button>
                    </form>
                )}
                <hr />
                <form onSubmit={handleCommentSubmit}>
                    <textarea
                        style={{ width: '500px', height: '50px' }}
                        value={comment}
                        onChange={(e) => setComment(e.target.value)}
                        placeholder="Add your comments here."
                    />
                    <br />
                    <button type="submit" disabled={issue.issue_is_closed}>
                        댓글 등록
                    </button>
                </form>
                <hr />
                <Link to={`/issueList/${issue.issue_project_no}`}>
                    <button>이슈 리스트</button>
                </Link>
                {issue.issue_author === loginName && (
                    <Link to={`/issueModify/${issue.issue_no}`}>
                        <button>내용 수정</button>
                    </Link>
                )}
                {issue.issue_is_closed ? (
                    <button onClick={() => axiosIssueReOpen(issue_no)}>이슈 재오픈</button>
                ) : (
                    <button onClick={() => axiosIssueClose(issue_no)}>이슈 닫기</button>
                )}
                <hr />
            </div>
        </div>
    )
}

export default IssueRead;