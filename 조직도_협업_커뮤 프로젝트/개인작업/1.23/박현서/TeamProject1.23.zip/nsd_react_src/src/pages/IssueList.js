import { useState, useEffect } from 'react';
import './Pages.css';
import axios from 'axios';
import { Link, useParams } from 'react-router-dom';

function IssueList() { 
    const { pjNo } = useParams(); // URL 파라미터에서 pjNo 가져오기
    const issue_project_no = parseInt(pjNo, 10); // 숫자 변환
    const [issues, setIssues] = useState([]); // 이슈 데이터 상태
    const [showClosed, setShowClosed] = useState(false); // 필터 상태

    // API 호출
    useEffect(() => {
        axiosGetIssue();
    }, []);

    function axiosGetIssue() {
        axios
            .get(`http://localhost:8080/spring/company/getIssue?pjNo=${issue_project_no}`)
            .then((response) => {
                setIssues(response.data); // 응답 데이터로 상태 업데이트
            })
            .catch((error) => {
                console.error('에러!', error);
            });
    }

    // 필터링된 이슈 데이터
    const filteredIssues = issues.filter((p) => p.issue_is_closed === showClosed);

    return (
        <>
            <div id="issue_list_page">
                <div id="list_box">
                    <h3>이슈 리스트</h3>
                    <div>
                        <button 
                            onClick={() => setShowClosed(false)} 
                            disabled={!showClosed} // Opened 버튼 비활성화 조건
                        >
                            Opened
                        </button>
                        <button 
                            onClick={() => setShowClosed(true)} 
                            disabled={showClosed} // Closed 버튼 비활성화 조건
                        >
                            Closed
                        </button>
                    </div>
                    {filteredIssues.map((p, i) => (
                        <div className="issue" key={i}>
                            <Link to={`/issueRead/${p.issue_no}`}>
                                <h2>{p.issue_title}</h2>
                            </Link>
                            #{p.issue_no} {p.issue_is_closed ? 'closed at' : 'opened at'}{' '}
                            {p.issue_is_closed ? p.issue_closedDate : p.issue_date} by {p.issue_author}
                        </div>
                    ))}
                    <hr />
                    <Link to="/"><button>프로젝트페이지로</button></Link>
                    <Link to={`/issueWrite/${pjNo}`}><button>이슈 등록</button></Link>
                    <hr />
                </div>
            </div>  
        </>
    );
}

export default IssueList;