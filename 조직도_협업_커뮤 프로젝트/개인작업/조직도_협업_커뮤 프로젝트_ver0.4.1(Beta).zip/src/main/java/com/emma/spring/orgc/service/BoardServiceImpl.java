package com.emma.spring.orgc.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emma.spring.orgc.dto.AdminBoardDto;
import com.emma.spring.orgc.dto.BoardDto;
import com.emma.spring.orgc.dto.CommentDto;
import com.emma.spring.orgc.dto.DeleteCommentDto;
import com.emma.spring.orgc.dto.DeleteDto;
import com.emma.spring.orgc.dto.ReadDto;
import com.emma.spring.orgc.dto.SearchBoardDto;
import com.emma.spring.orgc.dto.WriteCommentDto;
import com.emma.spring.orgc.dto.WriteDto;
import com.emma.spring.orgc.mapper.BoardMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class BoardServiceImpl implements BoardService {
	@Setter(onMethod_ = @Autowired)
	private BoardMapper mapper;

	@Override
	public ArrayList<BoardDto> getBoardList() {
		return mapper.getBoardList();
	}

	@Override
	public ArrayList<BoardDto> searchBoard(SearchBoardDto s) {
		return mapper.searchBoard(s);
	}

	@Override
	public ReadDto readBoard(Long postId) {
		ReadDto r = mapper.readBoard(postId);
		ArrayList<CommentDto> comments = mapper.getComments(postId);
		r.setComments(comments);

		return r;
	}

	@Override
	public void writeBoard(WriteDto w) {
		mapper.writeBoard(w);
	}

	@Override
	public ArrayList<AdminBoardDto> getAdminBoardList() {
		return mapper.getAdminBoardList();
	}

	@Override
	public void updateDeleteStatus(DeleteDto d) {
		mapper.updateDeleteStatus(d);
	}

	@Override
	public void writeComment(WriteCommentDto w) {
		mapper.writeComment(w);
	}

	@Override
	public void deleteComment(DeleteCommentDto d) {
		mapper.deleteComment(d);
	}
}
