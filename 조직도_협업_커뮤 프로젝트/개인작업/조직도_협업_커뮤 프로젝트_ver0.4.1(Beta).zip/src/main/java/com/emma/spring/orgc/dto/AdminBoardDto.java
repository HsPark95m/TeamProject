package com.emma.spring.orgc.dto;

import java.util.Date;

import lombok.Data;

@Data
public class AdminBoardDto {
	private Long post_id;
	private String title;
	private String author;
	private Date created_at;
	private Long view_count;
	private Boolean is_deleted;
}
