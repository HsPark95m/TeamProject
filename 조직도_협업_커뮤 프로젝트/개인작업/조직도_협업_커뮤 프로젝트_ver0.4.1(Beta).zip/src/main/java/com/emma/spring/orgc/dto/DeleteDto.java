package com.emma.spring.orgc.dto;

import lombok.Data;

@Data
public class DeleteDto {
	private Long postId;
	private Boolean isDeleted;
}
