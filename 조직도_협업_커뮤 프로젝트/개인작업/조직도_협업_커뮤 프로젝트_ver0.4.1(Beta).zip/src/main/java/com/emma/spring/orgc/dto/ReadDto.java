package com.emma.spring.orgc.dto;

import java.util.ArrayList;
import java.util.Date;

import lombok.Data;

@Data
public class ReadDto {
	private Long post_id;
	private String title;
	private String content;
	private String author;
	private Date created_at;
	private Date updated_at;
	private Long view_count;
	private Boolean is_deleted;
	public ArrayList<CommentDto> comments;
}
//post_id INT AUTO_INCREMENT PRIMARY KEY,                       -- 게시 글 ID (기본키)
//title VARCHAR(255) NOT NULL,                                  -- 게시 글 제목
//content TEXT NOT NULL,                                        -- 게시 글 내용
//author VARCHAR(100) NOT NULL,                                 -- 작성자 이름
//created_at DATETIME DEFAULT CURRENT_TIMESTAMP,               -- 작성일시
//updated_at DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP, -- 수정일시
//view_count INT DEFAULT 0,                                     -- 조회수
//is_deleted BOOLEAN DEFAULT FALSE                              -- 삭제 여부