package com.emma.spring.orgc.dto;

import lombok.Data;

@Data
public class EmpUpdatePDto {
	private String Emp_position;
	private String Emp_no;
}
