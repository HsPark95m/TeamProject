package com.emma.spring.orgc.dto;

import lombok.Data;

@Data
public class WriteDto {
	private String title;
	private String content;
	private String author;
}
