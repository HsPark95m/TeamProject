package com.emma.spring.orgc.dto;

import lombok.Data;

@Data
public class DeleteCommentDto {
	private Boolean isDeleted;
	private int commentId;
}
