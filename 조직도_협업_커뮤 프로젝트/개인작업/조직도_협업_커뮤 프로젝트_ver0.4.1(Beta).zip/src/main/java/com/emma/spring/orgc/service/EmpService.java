package com.emma.spring.orgc.service;

import java.util.ArrayList;

import com.emma.spring.orgc.dto.DepDto;
import com.emma.spring.orgc.dto.EmpDto;
import com.emma.spring.orgc.dto.EmpUpdateDDto;
import com.emma.spring.orgc.dto.EmpUpdatePDto;
import com.emma.spring.orgc.dto.LoginDto;

public interface EmpService {
	public ArrayList<EmpDto> getEmp();

	public ArrayList<EmpDto> getEmpByRank(Long rank);

	public boolean login(LoginDto log);

	public ArrayList<DepDto> getDep();

	public void updateEmpD(EmpUpdateDDto e);

	public void updateEmpP(EmpUpdatePDto e);

	public void closeDep(String depName);

	public void openDep(String depName);
}
