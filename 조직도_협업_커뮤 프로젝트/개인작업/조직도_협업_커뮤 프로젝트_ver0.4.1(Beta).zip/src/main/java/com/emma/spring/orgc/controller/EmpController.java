package com.emma.spring.orgc.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.emma.spring.orgc.dto.DepDto;
import com.emma.spring.orgc.dto.EmpDto;
import com.emma.spring.orgc.dto.EmpUpdateDDto;
import com.emma.spring.orgc.dto.EmpUpdatePDto;
import com.emma.spring.orgc.dto.LoginDto;
import com.emma.spring.orgc.service.EmpService;

import lombok.Setter;

@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/emp/*")
@RestController
public class EmpController {
	@Setter(onMethod_ = @Autowired)
	private EmpService service;

	@RequestMapping("/getEmp")
	public ArrayList<EmpDto> getEmp() {
		ArrayList<EmpDto> e = service.getEmp();
		return e;
	}

	@RequestMapping("/getEmpByRank")
	public ArrayList<EmpDto> getEmpByRank(@RequestParam("rank") Long rank) {
		return service.getEmpByRank(rank);
	}

	@RequestMapping("/login")
	public String login(@RequestBody LoginDto log) {
		String result = "";
		boolean islogin = service.login(log);
		if (islogin) {
			result = "success";
		} else {
			result = "failed";
		}
		return result;
	}

	@RequestMapping("/getDep")
	public ArrayList<DepDto> getDep() {
		return service.getDep();
	}

	@RequestMapping("/updateEmpD")
	public void updateEmpD(@RequestBody EmpUpdateDDto e) {
		service.updateEmpD(e);
	}

	@RequestMapping("/updateEmpP")
	public void updateEmpP(@RequestBody EmpUpdatePDto e) {
		service.updateEmpP(e);
	}

	@RequestMapping("/closeDep")
	public void closeDep(@RequestParam("depName") String depName) {
		service.closeDep(depName);
	}

	@RequestMapping("/openDep")
	public void openDep(@RequestParam("depName") String depName) {
		service.openDep(depName);
	}
}
