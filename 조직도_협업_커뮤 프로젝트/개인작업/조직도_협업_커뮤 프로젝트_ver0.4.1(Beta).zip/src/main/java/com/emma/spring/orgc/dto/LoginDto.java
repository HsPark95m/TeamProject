package com.emma.spring.orgc.dto;

import lombok.Data;

@Data
public class LoginDto {
	private String Emp_no;
	private String Emp_pw;
}
