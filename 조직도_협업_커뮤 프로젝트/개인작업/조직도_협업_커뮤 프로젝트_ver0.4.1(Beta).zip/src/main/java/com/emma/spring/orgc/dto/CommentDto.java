package com.emma.spring.orgc.dto;

import java.util.Date;

import lombok.Data;

@Data
public class CommentDto {
	private Long comment_id;
	private String TEXT;
	private String author;
	private Date created_at;
	private Boolean is_deleted;

}
//comment_id INT AUTO_INCREMENT PRIMARY KEY,     -- 댓글 ID(기본 키)
//post_id INT NOT NUll,                          -- 연관된 게시글 ID (외래 키)
//content TEXT NOT NULL,                         -- 댓글 내용
//author VARCHAR(100) NOT NULL,                  -- 작성자 이름
//created_at DATETIME DEFAULT CURRENT_TIMESTAMP, -- 작성일시
//is_deleted BOOLEAN DEFAULT FALSE,              -- 삭제여부
