package com.emma.spring.orgc.dto;

import lombok.Data;

@Data
public class EmpUpdateDto {
	private String Emp_no;
	private String Dep_name;
}
