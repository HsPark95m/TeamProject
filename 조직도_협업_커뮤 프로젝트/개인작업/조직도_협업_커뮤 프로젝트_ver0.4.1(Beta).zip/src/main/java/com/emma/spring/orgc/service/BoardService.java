package com.emma.spring.orgc.service;

import java.util.ArrayList;

import com.emma.spring.orgc.dto.AdminBoardDto;
import com.emma.spring.orgc.dto.BoardDto;
import com.emma.spring.orgc.dto.DeleteCommentDto;
import com.emma.spring.orgc.dto.DeleteDto;
import com.emma.spring.orgc.dto.ReadDto;
import com.emma.spring.orgc.dto.SearchBoardDto;
import com.emma.spring.orgc.dto.WriteCommentDto;
import com.emma.spring.orgc.dto.WriteDto;

public interface BoardService {
	public ArrayList<BoardDto> getBoardList();

	public ArrayList<BoardDto> searchBoard(SearchBoardDto s);

	public ReadDto readBoard(Long postId);

	public void writeBoard(WriteDto w);

	public ArrayList<AdminBoardDto> getAdminBoardList();

	public void updateDeleteStatus(DeleteDto d);

	public void writeComment(WriteCommentDto w);

	public void deleteComment(DeleteCommentDto d);
}
