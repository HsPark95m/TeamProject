package com.emma.spring.orgc.dto;

import lombok.Data;

@Data
public class WriteCommentDto {
	private int postId;
	private String content;
	private String author;
}
