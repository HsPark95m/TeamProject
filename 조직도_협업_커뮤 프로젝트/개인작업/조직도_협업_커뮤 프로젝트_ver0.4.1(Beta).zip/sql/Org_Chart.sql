use my_cat;

show tables;

drop table Employee;
create table Employee(
	Emp_no varchar(20) primary key,
    Emp_name varchar(20) not null default '사원테스트',
    Emp_dep varchar(20) not null default '부서테스트',
    Emp_position varchar(20) not null default '부장',
    Emp_rank int not null default 1,
    Emp_pw varchar(20)
);

DELIMITER $$

CREATE TRIGGER set_pw_equal_to_no
BEFORE INSERT ON Employee
FOR EACH ROW
BEGIN
    IF NEW.Emp_pw IS NULL THEN
        SET NEW.Emp_pw = NEW.Emp_no;
    END IF;
END$$

DELIMITER ;
INSERT INTO Employee (`Emp_no`,`Emp_name`,`Emp_dep`,`Emp_position`,`Emp_rank`) VALUES ('0000','나사장','이사회','사장',0)
,('0001','나부장','게임개발부','부장',1)
,('0002','나사원','게임개발부','사원',2)
,('0003','김부장','경영지원부','부장',1)
,('0004','김사원','경영지원부','사원',2)
,('0005','최사원','경영지원부','사원',2)
,('0006','박사원','경영지원부','사원',2)
,('0007','이부장','영업부','부장',1)
,('0008','이사원','영업부','사원',2)
,('0009','폐부테스트','무소속','사원',2);
-- ALTER TABLE Employee DROP COLUMN Emp_participate;

select * from Employee;

update Employee set Emp_rank = 1 and Emp_position = '부장' where Emp_no = '0001';
update Employee set Emp_dep = '영업부' where Emp_no = '0008';
UPDATE Employee
			SET Emp_position = '부장',
			    Emp_rank = CASE
			                 WHEN '부장' = '부장' THEN 1
			                 WHEN '부장' = '사원' THEN 2
			                 ELSE -1
			               END
			WHERE Emp_no LIKE '0008';

SELECT * from Employee ORDER BY Emp_rank desc;
SELECT * from Employee where Emp_rank=1 ORDER BY Emp_dep;
select * from Employee where Emp_dep='영업부' order by Emp_rank asc;
select * from employee WHERE Emp_dep LIKE '게임개발부' order by Emp_rank;
select * from employee WHERE Emp_rank!=0 order by Emp_dep;
select count(*) from employee WHERE Emp_no LIKE '0000' AND Emp_pw LIKE '0000';
select Emp_dep from employee group by Emp_dep;

drop table Cooperation_Project;
create table Cooperation_Project(
	Coop_no int primary key auto_increment,
	Coop_name varchar(50) not null default '무제',
    Coop_content varchar(50) not null default '설명란'
);
INSERT INTO Cooperation_Project (`Coop_name`) VALUES ('무제1');
INSERT INTO Cooperation_Project (`Coop_name`) VALUES ('무제2');
INSERT INTO Cooperation_Project (`Coop_name`) VALUES ('무제3');
select * from Cooperation_Project;

drop table Project_Management;
create table Project_Management(
	Emp_no varchar(20) not null,
    Coop_no int not null
);
INSERT INTO Project_Management (`Emp_no`, `Coop_no`) VALUES ('0005', 1);
INSERT INTO Project_Management (`Emp_no`, `Coop_no`) VALUES ('0001', 1);
INSERT INTO Project_Management (`Emp_no`, `Coop_no`) VALUES ('0001', 2);
INSERT INTO Project_Management (`Emp_no`, `Coop_no`) VALUES ('0006', 2);
INSERT INTO Project_Management (`Emp_no`, `Coop_no`) VALUES ('0008', 3);
delete from Project_Management where Emp_no='0001' and Coop_no=2;
select * from Project_Management;

drop table department;
create table department(
	dep_no	int primary key auto_increment,
    dep_name varchar(20) not null
);
insert into department (dep_name) value ('이사회');
insert into department (dep_name) value ('게임개발부');
insert into department (dep_name) value ('경영지원부');
insert into department (dep_name) value ('영업부');

select * from department;

drop table company_board_posts;

#회원 게시판
CREATE TABLE company_board_posts(
post_id INT AUTO_INCREMENT PRIMARY KEY,                       -- 게시 글 ID (기본키)
title VARCHAR(255) NOT NULL,                                  -- 게시 글 제목
content TEXT NOT NULL,                                        -- 게시 글 내용
author VARCHAR(100) NOT NULL,                                 -- 작성자 이름
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,               -- 작성일시
updated_at DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP, -- 수정일시
view_count INT DEFAULT 0,                                     -- 조회수
is_deleted BOOLEAN DEFAULT FALSE                              -- 삭제 여부
);

select * from company_board_posts;
insert into company_board_posts values();

insert into company_board_posts (title,content,author) values('첫 게시글','테이블테스트','0000'),
('페이징 테스트1','페이징 테스트 중','0000'),
('페이징 테스트2','페이징 테스트 중','0001'),
('페이징 테스트3','페이징 테스트 중','0003'),
('페이징 테스트4','페이징 테스트 중','0005'),
('페이징 테스트5','페이징 테스트 중','0007'),
('페이징 테스트6','페이징 테스트 중','0004'),
('페이징 테스트7','페이징 테스트 중','0005'),
('페이징 테스트8','페이징 테스트 중','0002'),
('페이징 테스트9','페이징 테스트 중','0003'),
('페이징 테스트10','페이징 테스트 중','0008'),
('페이징 테스트11','페이징 테스트 중','0001'),
('페이징 테스트12','페이징 테스트 중','0002'),
('페이징 테스트13','페이징 테스트 중','0005'),
('페이징 테스트14','페이징 테스트 중','0006'),
('페이징 테스트15','페이징 테스트 중','0007'),
('페이징 테스트16','페이징 테스트 중','0007');

update company_board_posts set title = '업데이트테스트' where author = '0000';

select * from company_board_posts;
select * from company_board_posts where title like '%오늘의%';
select * from company_board_posts where content like '%테스트%';
select * from company_board_posts where author like '%지우%';
select * from company_board_posts where is_deleted = true;
select is_deleted from company_board_posts;

update company_board_posts set is_deleted = true where post_id=1;

UPDATE company_board_posts set is_deleted = false where post_id = 1;

desc company_board_posts;


#댓글 테이블
CREATE TABLE company_board_comments(
comment_id INT AUTO_INCREMENT PRIMARY KEY,     -- 댓글 ID(기본 키)
post_id INT NOT NUll,                          -- 연관된 게시글 ID (외래 키)
content TEXT NOT NULL,                         -- 댓글 내용
author VARCHAR(100) NOT NULL,                  -- 작성자 이름
created_at DATETIME DEFAULT CURRENT_TIMESTAMP, -- 작성일시
is_deleted BOOLEAN DEFAULT FALSE,              -- 삭제여부
FOREIGN KEY (post_id) REFERENCES company_board_posts(post_id) ON DELETE CASCADE
);

select * from company_board_comments;
INSERT INTO company_board_comments (post_id, content, author) VALUES (1, '이 게시글 재미있네요', '누구게');
INSERT INTO company_board_comments (post_id, content, author) VALUES (1, '이 게시글 그저그런데요', '누구일까');

drop table company_board_comments;
