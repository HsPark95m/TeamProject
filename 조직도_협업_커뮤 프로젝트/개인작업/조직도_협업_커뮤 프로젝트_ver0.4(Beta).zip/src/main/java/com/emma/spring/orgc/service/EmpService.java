package com.emma.spring.orgc.service;

import java.util.ArrayList;

import com.emma.spring.orgc.dto.DepDto;
import com.emma.spring.orgc.dto.EmpDto;
import com.emma.spring.orgc.dto.EmpUpdateDto;
import com.emma.spring.orgc.dto.LoginDto;

public interface EmpService {
	public ArrayList<EmpDto> getEmp();

	public ArrayList<EmpDto> getEmpByRank(Long rank);

	public boolean login(LoginDto log);

	public ArrayList<DepDto> getDep();

	public void updateEmp(EmpUpdateDto e);
}
