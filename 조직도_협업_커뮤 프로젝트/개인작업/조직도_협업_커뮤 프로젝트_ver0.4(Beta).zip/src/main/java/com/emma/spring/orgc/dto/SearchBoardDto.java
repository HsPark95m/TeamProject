package com.emma.spring.orgc.dto;

import lombok.Data;

@Data
public class SearchBoardDto {
	String searchType;
	String searchWord;
}
