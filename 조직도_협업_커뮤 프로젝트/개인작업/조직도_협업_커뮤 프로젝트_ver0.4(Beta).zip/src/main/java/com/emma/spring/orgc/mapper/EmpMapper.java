package com.emma.spring.orgc.mapper;

import java.util.ArrayList;

import com.emma.spring.orgc.dto.DepDto;
import com.emma.spring.orgc.dto.EmpDto;
import com.emma.spring.orgc.dto.EmpUpdateDto;
import com.emma.spring.orgc.dto.LoginDto;

public interface EmpMapper {
	public ArrayList<EmpDto> getEmp();

	public ArrayList<EmpDto> getEmpByRank(Long rank);

	public int login(LoginDto log);

	public ArrayList<DepDto> getDep();

	public void updateEmp(EmpUpdateDto e);
}
