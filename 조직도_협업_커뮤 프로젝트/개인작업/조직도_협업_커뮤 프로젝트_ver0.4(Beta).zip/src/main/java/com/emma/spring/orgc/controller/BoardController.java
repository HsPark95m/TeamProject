package com.emma.spring.orgc.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.emma.spring.orgc.dto.AdminBoardDto;
import com.emma.spring.orgc.dto.BoardDto;
import com.emma.spring.orgc.dto.DeleteDto;
import com.emma.spring.orgc.dto.SearchBoardDto;
import com.emma.spring.orgc.service.BoardService;

import lombok.Setter;

@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/board/*")
@RestController
public class BoardController {
	@Setter(onMethod_ = @Autowired)
	private BoardService service;

	@RequestMapping("/getBoardList")
	public ArrayList<BoardDto> getBoardList() {
		return service.getBoardList();
	}

	@RequestMapping("/searchBoard")
	public ArrayList<BoardDto> searchBoard(@RequestBody SearchBoardDto s) {
		return service.searchBoard(s);
	}

	@RequestMapping("/getAdminBoardList")
	public ArrayList<AdminBoardDto> getAdminBoardList() {
		ArrayList<AdminBoardDto> a = service.getAdminBoardList();
		return a;
	}

	@RequestMapping("/updateDeleteStatus")
	public void updateDeleteStatus(@RequestBody DeleteDto d) {

		System.out.println(d.getIsDeleted());
		System.out.println(d.getPostId());
		service.updateDeleteStatus(d);
	}
}
