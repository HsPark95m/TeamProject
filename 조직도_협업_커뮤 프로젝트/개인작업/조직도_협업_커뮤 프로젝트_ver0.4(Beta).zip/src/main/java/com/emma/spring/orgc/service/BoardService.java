package com.emma.spring.orgc.service;

import java.util.ArrayList;

import com.emma.spring.orgc.dto.AdminBoardDto;
import com.emma.spring.orgc.dto.BoardDto;
import com.emma.spring.orgc.dto.DeleteDto;
import com.emma.spring.orgc.dto.SearchBoardDto;

public interface BoardService {
	public ArrayList<BoardDto> getBoardList();

	public ArrayList<BoardDto> searchBoard(SearchBoardDto s);

	public ArrayList<AdminBoardDto> getAdminBoardList();

	public void updateDeleteStatus(DeleteDto d);
}
