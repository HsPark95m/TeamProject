use my_cat;
show tables;
SHOW TRIGGERS;		
show databases;

drop table company_member;
create table company_member(
	company_name varchar(20) not null,
	company_id varchar(20) primary key,
    password varchar(20) not null,
    position varchar(20),
    position_rank int default 7,
    department varchar(20) default '',
    profile_photo varchar(5) DEFAULT '1'
);

select * from company_member order by position_rank asc;
INSERT INTO company_member (company_name, company_id, password, position, position_rank, department, profile_photo) VALUES
('김철수', 'boss', '00', '사장', 1, '', '3'),

-- 부장 4명
('이영희', 'w1', '11', '부장', 2, '기획', '2'),
('박민수', 'w2', '22', '부장', 2, '관리', '4'),
('정하나', 'w3', '33', '부장', 2, '영업', '5'),
('최준호', 'w4', '44', '부장', 2, '개발', '1'),

-- 차장 4명
('강수진', 'w5', '55', '차장', 3, '기획', '5'),
('배도윤', 'w6', '66', '차장', 3, '관리', '1'),
('윤가람', 'w7', '77', '차장', 3, '영업', '3'),
('서우진', 'w8', '88', '차장', 3, '개발', '2'),

-- 과장 4명
('이서윤', 'w9', '99', '과장', 4, '기획', '4'),
('조한결', 'w10', '1010', '과장', 4, '관리', '2'),
('문지후', 'w11', '1111', '과장', 4, '영업', '5'),
('노유빈', 'w12', '1212', '과장', 4, '개발', '3'),

-- 대리 6명
('안도현', 'w13', '1313', '대리', 5, '기획', '1'),
('송하은', 'w14', '1414', '대리', 5, '관리', '5'),
('이준서', 'w15', '1515', '대리', 5, '영업', '3'),
('최수빈', 'w16', '1616', '대리', 5, '개발', '4'),
('김다온', 'w17', '1717', '대리', 5, '기획', '2'),
('백예린', 'w18', '1818', '대리', 5, '관리', '1'),

-- 주임 6명
('박서진', 'w19', '1919', '주임', 6, '영업', '3'),
('정유나', 'w20', '2020', '주임', 6, '개발', '5'),
('이호준', 'w21', '2121', '주임', 6, '기획', '2'),
('김채은', 'w22', '2222', '주임', 6, '관리', '1'),
('윤도영', 'w23', '2323', '주임', 6, '영업', '4'),
('강예진', 'w24', '2424', '주임', 6, '개발', '2'),

-- 사원 8명
('신우진', 'w25', '2525', '사원', 7, '기획', '5'),
('최다정', 'w26', '2626', '사원', 7, '관리', '1'),
('이하늘', 'w27', '2727', '사원', 7, '영업', '3'),
('김태양', 'w28', '2828', '사원', 7, '개발', '4'),
('박시온', 'w29', '2929', '사원', 7, '기획', '2'),
('송지안', 'w30', '3030', '사원', 7, '관리', '5'),
('조민지', 'w31', '3131', '사원', 7, '영업', '3'),
('강서우', 'w32', '3232', '사원', 7, '개발', '1'),

('admin', 'admin', '00', '관리자', 0, '', '1');


##사원 비밀번호 자동 입력 트리거 
DELIMITER $$
CREATE TRIGGER set_pw_auto_generation_trigger 
BEFORE INSERT ON company_member
FOR EACH ROW
BEGIN
    IF NEW.password IS NULL THEN					## password 는 변수명임..
        -- password에 company_id 값과 추가 문자열 'a'를 결합하여 설정
        SET NEW.password = CONCAT(NEW.company_id, '00');
    END IF;
END$$
DELIMITER ;
DROP TRIGGER IF EXISTS set_pw_auto_generation_trigger;		## 트리거 삭제문

drop table department_list;
create table department_list(
	department_no int primary key auto_increment,
	department_name varchar(20),
    team_leader varchar(20) default '미정'
);
select * from department_list;
INSERT INTO department_list (department_name, team_leader) VALUES
('기획', '이영희'),
('관리', '박민수'),
('영업', '정하나'),
('개발', '최준호');

drop table project_list;
create table project_list(
	project_no int primary key auto_increment,
	project_name varchar(50) ,
	project_content varchar(50),
    project_startDate date,
    project_endDate date,
    is_finished boolean default false
);
select * from project_list;
SELECT * from project_list where is_finished = true order by project_startDate;

INSERT INTO project_list (project_name, project_content, project_startDate, project_endDate, is_finished) VALUES
('AI 챗봇 개발', '고객 응대 AI 챗봇 개발 프로젝트', '2025-01-15', '2025-06-30', false),
('ERP 시스템 구축', '기업 자원 관리 시스템 개발', '2024-11-01', '2025-07-31', false),
('모바일 쇼핑 앱', '온라인 쇼핑 애플리케이션 개발', '2025-02-01', '2025-08-15', false),
('IoT 스마트홈 시스템', '스마트홈 IoT 플랫폼 구축', '2024-04-10', '2024-12-21', true);

drop table project_member_list;
create table project_member_list(
	company_id varchar(20),
    project_no int
);
select * from project_member_list;
INSERT INTO project_member_list (company_id, project_no) VALUES
('w1', 1), ('w5', 1), ('w9', 1), ('w13', 1), ('w17', 1),
('w2', 2), ('w6', 2), ('w10', 2), ('w14', 2), ('w18', 2),
('w3', 3), ('w7', 3), ('w11', 3), ('w15', 3), ('w19', 3),
('w4', 4), ('w8', 4), ('w12', 4), ('w16', 4), ('w20', 4);


## 이슈 리스트 테이블
drop table project_issue_list;
create table project_issue_list(
	issue_no int primary key auto_increment,
    issue_project_no int not null,
    issue_title varchar(50),
    issue_details text,
    issue_label varchar(20),
    issue_author varchar(20),
    issue_datetime datetime default now(),
    issue_is_closed boolean default false,
    issue_closer varchar(20) default '',
    issue_closedDatetime datetime
);
select * from project_issue_list;
-- AI 챗봇 개발 프로젝트
INSERT INTO project_issue_list (issue_project_no, issue_title, issue_details, issue_label, issue_author, issue_datetime, issue_is_closed, issue_closer, issue_closedDatetime) VALUES
(1, '챗봇의 음성 인식 정확도 문제', '현재 챗봇의 음성 인식 정확도가 낮아 사용자 불만이 발생하고 있습니다. 개선이 시급합니다.', '버그', '이영희', '2024-02-10 14:30:00', false, '', NULL),
(1, '대화 시나리오 추가 필요', '고객의 다양한 질문에 대응하기 위해 대화 시나리오가 추가되어야 합니다.', '개선', '강수진', '2024-03-01 10:00:00', false, '', NULL);

-- ERP 시스템 구축 프로젝트
INSERT INTO project_issue_list (issue_project_no, issue_title, issue_details, issue_label, issue_author, issue_datetime, issue_is_closed, issue_closer, issue_closedDatetime) VALUES
(2, '시스템 속도 저하', 'ERP 시스템의 속도가 매우 느려서 업무에 지장이 있습니다. 성능 최적화가 필요합니다.', '성능', '박민수', '2024-01-20 16:45:00', false, '', NULL),
(2, '사용자 인터페이스 불편함', '시스템의 사용자 인터페이스가 직관적이지 않아 사용자들이 혼란스러워하고 있습니다.', 'UI/UX', '배도윤', '2024-02-15 09:30:00', false, '', NULL);

-- 모바일 쇼핑 앱 프로젝트
INSERT INTO project_issue_list (issue_project_no, issue_title, issue_details, issue_label, issue_author, issue_datetime, issue_is_closed, issue_closer, issue_closedDatetime) VALUES
(3, '결제 시스템 오류', '결제 페이지에서 오류가 발생하여 결제 진행이 되지 않습니다. 긴급히 해결해야 합니다.', '버그', '윤가람', '2024-02-10 11:00:00', false, '', NULL),
(3, '장바구니에 아이템 추가 불가', '장바구니에 상품을 추가할 수 없는 문제가 발생하고 있습니다.', '버그', '문지후', '2024-02-03 15:20:00', false, '', NULL);

-- IoT 스마트홈 시스템
INSERT INTO project_issue_list (issue_project_no, issue_title, issue_details, issue_label, issue_author, issue_datetime, issue_is_closed, issue_closer, issue_closedDatetime) VALUES
(4, '스마트 기기 연결 불안정', '일부 스마트 기기와의 연결이 불안정하여 사용자들이 불편을 겪고 있습니다.', '버그', '정하나', '2023-11-05 18:00:00', false, '', NULL),
(4, '사용자 인증 방식 개선 필요', '현재 인증 방식이 복잡하여 사용자가 로그인을 어려워하고 있습니다. 개선이 필요합니다.', '개선', '서우진', '2024-01-15 13:00:00', false, '', NULL);

## 이슈 코멘트 테이블
drop table project_issue_comment;
create table project_issue_comment(
	comment_no int primary key auto_increment,
    comment_issue_no int not null,
    comment_text text,
    comment_author varchar(20),
    comment_datetime datetime default now()
);
select * from project_issue_comment;
INSERT INTO project_issue_comment (comment_issue_no, comment_text, comment_author, comment_datetime) VALUES
(1, '음성 인식 정확도를 높이기 위한 알고리즘 개선이 필요할 것 같습니다. 기존 모델의 데이터를 다시 학습시키면 도움이 될 것입니다.', '강수진', '2024-02-11 09:15:00'),
(1, '다른 고객들이 경험한 비슷한 문제를 참고하여 음성 인식 기능을 개선해 보겠습니다. 데이터를 추가로 수집해야 할 것 같습니다.', '이서윤', '2024-02-12 16:30:00'),
(2, '대화 시나리오를 추가하려면 우선 주요 고객의 질문 패턴을 분석하고, 그에 맞는 시나리오를 만들면 좋겠습니다.', '안도현', '2024-03-02 10:00:00'),
(2, '고객 서비스 팀과 협업하여 실제 사용자들이 자주 묻는 질문을 반영한 시나리오를 작성해야 할 것 같습니다.', '이영희', '2024-03-03 11:45:00'),
(3, '성능 최적화를 위해 서버의 리소스를 증설하거나, 데이터베이스 인덱스를 재구성하는 방법을 고려해야 할 것 같습니다.', '배도윤', '2024-01-22 14:10:00'),
(3, '애플리케이션에서 불필요한 데이터를 로드하지 않도록 쿼리 최적화를 진행해야 할 필요가 있습니다. 성능 테스트도 함께 해봐야 합니다.', '조한결', '2024-01-25 13:20:00'),
(4, 'UI/UX 개선을 위해 사용자의 피드백을 반영한 디자인 개편을 고려해야 할 것 같습니다. 특히 버튼 위치와 텍스트가 불편합니다.', '박민수', '2024-02-16 09:40:00'),
(4, '더 직관적인 인터페이스를 위해 사용자 경험을 분석하고, 대시보드와 같은 주요 화면을 개선하는 것이 좋겠습니다.', '배도윤', '2024-02-18 08:30:00'),
(5, '결제 시스템 오류는 서버와의 연결 문제일 수 있습니다. 로그를 확인하고 서버 성능을 점검해야 할 것 같습니다.', '정하나', '2024-02-11 14:20:00'),
(5, '이 문제는 사용자가 결제를 시도할 때마다 발생하는데, 결제 모듈을 업데이트하고 테스트해야 할 필요가 있습니다.', '윤가람', '2024-02-12 11:05:00'),
(6, '장바구니 문제는 프론트엔드에서 아이템을 추가할 때 발생하는 것 같습니다. 코드 리팩토링을 시도해야 할 것 같습니다.', '이준서', '2024-02-04 10:30:00'),
(6, '백엔드에서 장바구니 데이터를 제대로 전달하고 있는지 점검해야 할 것 같습니다. API 호출 시 문제가 있을 수 있습니다.', '박서진', '2024-02-05 12:15:00'),
(7, '스마트 기기 간의 연결 문제는 주로 Wi-Fi 신호가 불안정해서 발생하는 것 같습니다. 네트워크 점검을 권장합니다.', '최준호', '2023-11-06 11:00:00'),
(7, '기기 간의 통신 프로토콜을 점검하고, 최신 펌웨어로 업데이트하는 것이 좋겠습니다.', '노유빈', '2023-11-07 16:45:00'),
(8, '인증 방식 개선을 위해 더 간편한 로그인 방법을 추가해야 할 것 같습니다. 예를 들어, 소셜 로그인 연동 등을 고려할 수 있습니다.', '최수빈', '2024-01-16 09:30:00'),
(8, '현재의 인증 절차를 간소화하는 작업이 필요하며, 특히 두 단계 인증을 도입하면 보안이 강화될 것입니다.', '노유빈', '2024-01-17 10:10:00');

##여기부터 게시판
drop table company_board;
create table company_board(
	cb_no int primary key auto_increment, ##글번호 
    company_id varchar(20),	##작성자id
	company_name varchar(20),	##작성자 이름
    cb_title varchar(255),		##글제목
    cb_text text,			##글내용
    cb_category varchar(50),	##카테고리
    cb_datetime DATETIME DEFAULT now(),	##작성 날짜
    cb_modify_datetime DATETIME DEFAULT now(), ##수정 날짜
    cb_hits int default 0,	##조회수
    cb_is_deleted BOOLEAN DEFAULT FALSE ##삭제 로직
);
select * from company_board order by cb_no desc;

INSERT INTO company_board (company_id, company_name, cb_title, cb_text, cb_category, cb_datetime, cb_modify_datetime, cb_hits, cb_is_deleted) VALUES
('boss', '김철수', '아재개그', '이것은 뭘까요?', '자유', '2025-01-22 09:37:25', '2025-01-22 09:37:25', 0, FALSE),
('w1', '이영희', '영화 감상', '오징어 게임2 재미있어요.', '자유', '2025-01-22 09:37:26', '2025-01-22 09:37:26', 0, FALSE),
('w2', '박민수', '주식 토크', '요즘 주식이 올랐어요.', '자유', '2025-01-22 09:37:26', '2025-01-22 09:37:26', 0, FALSE),
('w3', '정하나', '취미 생활', '최근에 취미로 배드민턴을 하고 있어요.', '자유', '2025-01-22 09:37:29', '2025-01-22 09:37:29', 0, FALSE),
('w4', '최준호', '퇴근 후 풋살', '오늘도 퇴근 후에 풋살 차실래요?', '자유', '2025-01-22 09:37:29', '2025-01-22 09:37:29', 0, FALSE),
('w5', '강수진', '신입사원', '안녕하십니까 신입사원 강수진입니다.', '자유', '2025-01-22 09:37:29', '2025-01-22 09:37:29', 0, FALSE),
('w6', '배도윤', '점심메뉴', '점심시간에 돈까스를 먹었습니다.', '자유', '2025-01-22 09:37:30', '2025-01-22 09:37:30', 157, FALSE),
('w7', '윤가람', '결재 서류 확인', '결재 받을게 있는데 지금 가도 되나요?', '자유', '2025-01-22 09:37:30', '2025-01-22 09:37:30', 0, FALSE),
('w8', '서우진', '건강 이슈로 인한 조퇴', '몸이 안 좋아서 먼저 조퇴하겠습니다.', '자유', '2025-01-22 09:37:31', '2025-01-22 09:37:31', 2, FALSE),
('w9', '이서윤', '2025년 새해가 시작되었어요', '새해 복 많이 받으세요.', '자유', '2025-01-22 09:37:32', '2025-01-22 09:37:32', 4, FALSE),
('boss', '김철수', '프로젝트 진행 현황', '디자인 작업 중', '공지', '2025-01-22 10:17:18', '2025-01-22 10:17:18', 1, FALSE),
('boss', '김철수', '디자인 작업내용', '게시판 탭 분리 or 통합 버전\n\n마이페이지 프로필 이미지 크기 동일하게 / 배치 고민\n\n이슈페이지 디자인 작업 중', '공지', '2025-01-22 10:19:25', '2025-01-22 10:19:25', 8, FALSE),
('boss', '김철수', '인기글 테스트', '인기글 <img src="http://localhost:8080/spring/uploads/f60882c7-011a-4dcb-89d2-3885b35d556d_test2.webp" alt="첨부 이미지">', '자유', '2025-02-05 15:29:33', '2025-02-05 15:29:33', 2, FALSE);

INSERT INTO company_board (company_id, company_name, cb_title, cb_text, cb_category) VALUES
('w9', '이서윤', '점심 뭐 먹지?', '오늘 점심 뭐 먹을까요? 다들 추천 좀 해주세요!', '자유'),
('w10', '조한결', '업무 프로세스 개선 건의', '현재 결재 시스템이 너무 오래 걸립니다. 개선이 필요해 보입니다.', '건의'),
('w11', '문지후', '주말에 등산 가실 분!', '이번 주말에 북한산 등산 가실 분 계신가요? 초보 환영입니다!', '취미'),
('w12', '노유빈', '회의 시간 조정 요청', '매주 월요일 오전 9시 회의가 너무 힘듭니다. 오후로 조정 가능할까요?', '건의'),
('w9', '이서윤', '오늘 퇴근 후 번개?', '퇴근하고 간단히 한잔할 사람 있나요? 댓글 달아주세요~', '자유'),
('w10', '조한결', '헬스장 같이 다니실 분!', '회사 근처 헬스장 등록할까 하는데 같이 다니실 분 찾습니다.', '취미'),
('w11', '문지후', '모니터 추가 지급 요청', '업무할 때 듀얼 모니터가 필요합니다. 추가 지급 가능할까요?', '건의'),
('w12', '노유빈', '넷플릭스 추천 좀 해주세요', '요즘 볼만한 드라마나 영화 있을까요? 추천 부탁드려요!', '자유'),
('w9', '이서윤', '독서 모임 모집', '월 1회 독서 모임 진행하려고 합니다. 관심 있으신 분 댓글 주세요!', '취미'),
('w10', '조한결', '점심시간 늘릴 수 없을까요?', '현재 점심시간이 1시간인데 1시간 30분으로 늘릴 수 있을까요?', '건의'),
('w11', '문지후', '사내 동아리 개설 희망', '요가 동아리 만들고 싶은데 관심 있는 분 있나요?', '취미'),
('w12', '노유빈', '출퇴근 시간 유연 근무 제안', '출퇴근 시간을 조금 조정하면 효율이 올라갈 것 같은데 의견 주세요!', '건의'),
('w9', '이서윤', '이번 주말 날씨 대박!', '주말에 날씨가 너무 좋다고 하네요. 나들이 계획 있으신가요?', '자유'),
('w10', '조한결', '캠핑 동호회 모집', '1박 2일 캠핑 함께 하실 분 계신가요? 초보도 환영입니다!', '취미'),
('w11', '문지후', '회의실 예약 시스템 개선 요청', '회의실 예약이 너무 어렵습니다. 개선이 필요해 보입니다.', '건의'),
('w12', '노유빈', '이직 고민 중...', '요즘 회사에서 고민이 많습니다. 다들 이직 생각해보신 적 있나요?', '자유'),
('w9', '이서윤', '야구 같이 보러 가실 분!', '이번 주말 야구 직관 가실 분 구합니다!', '취미'),
('w10', '조한결', '새로운 휴게 공간 마련 제안', '사무실 내 휴게 공간이 부족한데 추가 공간 마련이 가능할까요?', '건의'),
('w11', '문지후', '회사 앞 맛집 공유', '회사 근처에서 가장 맛있는 식당은 어디일까요? 추천 부탁드립니다.', '자유'),
('w12', '노유빈', '퇴근 후 러닝모임 모집', '러닝 모임 시작하려고 합니다. 초보자도 환영합니다!', '취미'),
('w9', '이서윤', '팀 회식 날짜 조율', '팀 회식 일정 조정이 필요해 보입니다. 다들 가능한 날짜 남겨주세요!', '자유'),
('w10', '조한결', '회사 내 자판기 추가 요청', '자판기가 한 대뿐이라 줄이 너무 깁니다. 추가 가능할까요?', '건의'),
('w11', '문지후', '게임 같이 하실 분!', '퇴근 후 롤이나 배그 하실 분 구해요!', '취미'),
('w12', '노유빈', '주차 공간 문제 해결 요청', '주차 공간이 너무 부족합니다. 개선 방안이 필요합니다.', '건의'),
('w9', '이서윤', '사무실 온도 조절 좀...', '너무 덥거나 너무 춥거나... 온도 조절 좀 해주세요!', '건의'),
('w10', '조한결', '이번 주말 캠핑 떠나요!', '같이 캠핑 가실 분 모집합니다! 초보 환영!', '취미'),
('w11', '문지후', '코딩 스터디 모집', '개발자분들 함께 공부하실 분 찾습니다!', '취미'),
('w12', '노유빈', '출근 시간 변경 가능?', '조금 더 유연하게 출퇴근하면 어떨까요? 의견 주세요!', '건의'),
('w9', '이서윤', '다들 점심 먹었나요?', '오늘 점심 뭐 드셨나요? 추천 좀 해주세요!', '자유'),
('w10', '조한결', '퇴근 후 볼링 치러 가실 분!', '볼링 치러 갈 사람 구합니다!', '취미'),
('w11', '문지후', '사내 워크숍 제안', '팀 빌딩을 위해 워크숍을 가면 어떨까요?', '건의'),
('w12', '노유빈', '명절 선물 추천', '명절 선물 뭐가 좋을까요? 추천 부탁드립니다.', '자유'),
('w9', '이서윤', '헬스장 등록하려고 하는데...', '헬스장 추천 좀 해주세요!', '취미'),
('w10', '조한결', '노트북 업그레이드 요청', '업무용 노트북이 너무 느려요. 업그레이드 가능할까요?', '건의'),
('w11', '문지후', '영화 보러 가실 분?', '이번 주말 신작 보러 가실 분?', '취미'),
('w12', '노유빈', '사무실 정수기 문제', '정수기에서 이상한 맛이 나는데 점검 요청드립니다.', '건의'),
('w9', '이서윤', '커피 마실 사람!', '점심 먹고 커피 한 잔 하실 분?', '자유'),
('w10', '조한결', '개발자 스터디 그룹 모집', '프로그래밍 공부 함께 하실 분 구합니다!', '취미'),
('w11', '문지후', '회식 메뉴 추천', '회식 메뉴 추천해주세요! 고기? 회?', '자유'),
('w12', '노유빈', '출퇴근 교통비 지원 가능?', '대중교통비 지원이 있으면 좋겠는데 가능할까요?', '건의');

update company_board set cb_hits = 300, cb_datetime = '2025-02-01 12:00:00', cb_modify_datetime = '2025-02-01 12:00:00' where cb_no = 23;

drop table company_board_comment;
create table company_board_comment(
	comment_no int primary key auto_increment,
	cb_no int,		##해당 글번호
    company_id varchar(20),	##댓글 작성자id
	company_name varchar(20),	##작성자 이름
    cb_comment_text text,	##댓글 내용
    cb_comment_datetime DATETIME DEFAULT now(),	##댓글 작성 날짜
    cb_comment_is_deleted BOOLEAN DEFAULT FALSE,	##삭제 로직
    FOREIGN KEY (cb_no) REFERENCES company_board(cb_no) ON DELETE CASCADE ##메인 게시글 삭제 시 댓글 자동 삭제 로직
);
select * from company_board_comment;
INSERT INTO company_board_comment (cb_no, company_id, company_name, cb_comment_text) VALUES
(4, 'w6', '배도윤', '배드민턴 저도 좋아하는데 같이 쳐요!'),
(4, 'w7', '윤가람', '초보도 괜찮다면 한번 해보고 싶어요!'),
(6, 'w8', '서우진', '반갑습니다! 즐겁게 일해봐요~'),
(6, 'w9', '이서윤', '신입사원이라니! 앞으로 잘 부탁드립니다!'),
(8, 'w10', '조한결', '결재는 오후 2시 이후로 가능합니다. 그때 오세요!'),
(8, 'w11', '문지후', '지금 자리에 계신가요? 제가 직접 가겠습니다!'),
(10, 'w12', '노유빈', '새해 복 많이 받으세요! 2025년엔 좋은 일만 가득하길!'),
(10, 'w1', '이영희', '다들 올 한 해 목표는 뭔가요? 저는 여행 더 다니는 게 목표입니다!'),
(15, 'w2', '박민수', '저도 결재 시스템 불편하다고 느꼈어요. 개선된다면 업무가 훨씬 수월할 것 같네요.'),
(15, 'w3', '정하나', '이거 예전부터 문제였죠. 자동화 시스템 도입하면 좀 나아질까요?'),
(20, 'w4', '최준호', '듀얼 모니터 진짜 필수죠. 있으면 업무 속도가 훨씬 빨라져요!'),
(20, 'w5', '강수진', '저도 모니터 한 대 더 있으면 좋겠어요. 화면 전환이 너무 불편해요!'),
(25, 'w6', '배도윤', '출퇴근 시간 조정 찬성합니다! 30분만 늦출 수 있어도 훨씬 나을 것 같아요.'),
(25, 'w7', '윤가람', '플렉서블 근무제 도입하면 출퇴근 스트레스가 줄어들 것 같아요!'),
(30, 'w8', '서우진', '야구 직관 가고 싶어요! 어느 구장에서 보시나요?'),
(30, 'w9', '이서윤', '저는 두산 팬인데 혹시 같은 팀 응원하시나요? ㅎㅎ'),
(31, 'w10', '조한결', '휴게공간 추가되면 너무 좋을 것 같아요! 지금 너무 좁아요.'),
(31, 'w11', '문지후', '소파라도 하나 더 있으면 좋겠네요. 쉬는 공간이 부족해요!'),
(35, 'w12', '노유빈', '자판기 추가 찬성합니다! 점심시간에 줄 너무 길어요.'),
(35, 'w1', '이영희', '특히 커피 머신 있는 자판기 추가되면 최고일 것 같아요!');
## 카테고리 관리 로직
create table company_board_category(
	cb_category_name varchar(50)
);
select * from company_board_category;
insert into company_board_category(cb_category_name) values('전체'), ('공지'), ('자유'), ('건의'), ('취미');

create table trendingPeriod(
	period varchar(50),
    select_period int default 0
);
select * from trendingPeriod;
insert into trendingPeriod(period) values('day');
insert into trendingPeriod(period) values('week');
insert into trendingPeriod(period) values('month');
UPDATE trendingPeriod set select_period = 1 where period ='day';