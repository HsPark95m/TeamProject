package com.project.dto;

import lombok.Data;

@Data
public class ProjectMemberDto {
	private String company_id;
	private int project_no;
}
