import React from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import photo1 from '../images/pixel_art_split_1.png'
import photo2 from '../images/pixel_art_split_2.png'
import photo3 from '../images/pixel_art_split_3.png'
import photo4 from '../images/pixel_art_split_4.png'

// npm install react-slick --save
// npm install slick-carousel --save

function AutoPlay() {
  const settings = {
    dots: true,
    infinite: true,
    speed: 1000,
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 3000,
    pauseOnHover: true,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1
        }
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      }
    ]
  };
  return (
    <div className="slider-container">
      <Slider {...settings}>
        <div>
          <a href="https://www.google.com"><img src={photo1} alt="photo1" /></a>
        </div>
        <div>
          <a href="https://www.google.com"><img src={photo2} alt="photo2" /></a>
        </div>
        <div>
          <img src={photo3} alt="photo3" />
        </div>
        <div>
          <img src={photo4} alt="photo4" />
        </div>
      </Slider>
    </div>
  );
}

export default AutoPlay;
