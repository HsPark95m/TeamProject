-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: my_cat
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `company_board_posts`
--

DROP TABLE IF EXISTS `company_board_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `company_board_posts` (
  `post_id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `author` varchar(100) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `view_count` int DEFAULT '0',
  `is_deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company_board_posts`
--

LOCK TABLES `company_board_posts` WRITE;
/*!40000 ALTER TABLE `company_board_posts` DISABLE KEYS */;
INSERT INTO `company_board_posts` VALUES (1,'첫 게시글','테이블테스트','케로로','2024-12-23 12:01:43',NULL,0,0),(2,'페이징 테스트1','페이징 테스트 중','피카츄','2024-12-23 12:01:43',NULL,0,0),(3,'페이징 테스트2','페이징 테스트 중','케로로','2024-12-23 12:01:44',NULL,0,0),(4,'페이징 테스트3','페이징 테스트 중','기로로','2024-12-23 12:01:44',NULL,0,0),(5,'페이징 테스트4','페이징 테스트 중','타마마','2024-12-23 12:01:45',NULL,0,0),(6,'페이징 테스트5','페이징 테스트 중','쿠루루','2024-12-23 12:01:45',NULL,0,0),(7,'페이징 테스트6','페이징 테스트 중','도로로','2024-12-23 12:01:46',NULL,0,0),(8,'페이징 테스트7','페이징 테스트 중','기루루','2024-12-23 12:01:46',NULL,0,0),(9,'페이징 테스트8','페이징 테스트 중','도라에몽','2024-12-23 12:01:47',NULL,0,0),(10,'페이징 테스트9','페이징 테스트 중','노진구','2024-12-23 12:01:47',NULL,0,0),(11,'페이징 테스트10','페이징 테스트 중','비실이','2024-12-23 12:01:48',NULL,0,0),(12,'페이징 테스트11','페이징 테스트 중','이슬이','2024-12-23 12:01:48',NULL,0,0),(13,'페이징 테스트12','페이징 테스트 중','나루토','2024-12-23 12:01:48',NULL,0,0),(14,'페이징 테스트13','페이징 테스트 중','사스케','2024-12-23 12:01:49',NULL,0,0),(15,'페이징 테스트14','페이징 테스트 중','이타치','2024-12-23 12:01:49',NULL,0,0),(16,'페이징 테스트15','페이징 테스트 중','사쿠라','2024-12-23 12:01:50',NULL,0,0),(17,'페이징 테스트16','페이징 테스트 중','카카시','2024-12-23 12:01:50',NULL,0,0);
/*!40000 ALTER TABLE `company_board_posts` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-16  9:41:32
