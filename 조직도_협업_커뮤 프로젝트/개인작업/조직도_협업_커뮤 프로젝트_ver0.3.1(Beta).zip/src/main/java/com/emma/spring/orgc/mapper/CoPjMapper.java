package com.emma.spring.orgc.mapper;

import java.util.ArrayList;

import com.emma.spring.orgc.dto.CoPjDto;
import com.emma.spring.orgc.dto.MemberAddDto;

public interface CoPjMapper {
	public ArrayList<CoPjDto> getCoPj();

	public void closeCoPj(Long pjNo);

	public void pjMemberAdd(MemberAddDto m);

	public ArrayList<MemberAddDto> getCoPjMember();

	public void removeFromCoPj(MemberAddDto m);
}
