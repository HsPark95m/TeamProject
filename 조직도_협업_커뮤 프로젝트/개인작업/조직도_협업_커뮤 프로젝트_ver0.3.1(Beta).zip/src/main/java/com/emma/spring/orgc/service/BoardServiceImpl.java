package com.emma.spring.orgc.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emma.spring.orgc.dto.BoardDto;
import com.emma.spring.orgc.dto.SearchBoardDto;
import com.emma.spring.orgc.mapper.BoardMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class BoardServiceImpl implements BoardService {
	@Setter(onMethod_ = @Autowired)
	private BoardMapper mapper;

	@Override
	public ArrayList<BoardDto> getBoardList() {
		return mapper.getBoardList();
	}

	@Override
	public ArrayList<BoardDto> searchBoard(SearchBoardDto s) {
		return mapper.searchBoard(s);
	}
}
