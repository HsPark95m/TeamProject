package com.emma.spring.orgc.dto;

import java.util.ArrayList;

import lombok.Data;

@Data
public class DepDto {
	private Long dep_no;
	private String dep_name;
	public ArrayList<EmpDto> dep_mem = new ArrayList<EmpDto>();
}
