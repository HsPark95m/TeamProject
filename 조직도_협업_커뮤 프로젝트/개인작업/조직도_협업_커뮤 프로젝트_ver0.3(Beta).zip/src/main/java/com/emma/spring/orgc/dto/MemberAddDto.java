package com.emma.spring.orgc.dto;

import lombok.Data;

@Data
public class MemberAddDto {
	private String Emp_no;
	private Long Coop_no;
}
