package com.emma.spring.orgc.mapper;

import java.util.ArrayList;

import com.emma.spring.orgc.dto.BoardDto;
import com.emma.spring.orgc.dto.SearchBoardDto;

public interface BoardMapper {
	public ArrayList<BoardDto> getBoardList();

	public ArrayList<BoardDto> searchBoard(SearchBoardDto s);
}
