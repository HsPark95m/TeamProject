import { useRef, useState } from 'react';
// import './Board.css';
import axios from 'axios';

function IssueWrite({ loginId, loginName, pjNo, page }) { //loginId 굳이 안넘어와도 될듯? 세션으로 그냥 꺼내면 됨 BoardRead.js 참조
    const id = useRef();
    const name = useRef();
    const no = useRef();
    const title = useRef();
    const details = useRef();
    const [label, setLabel] = useState('');

    function axiosIssueWrite(e) {
        e.preventDefault();
        if(title.current.value === '' || details.current.value === '' || label === ''){
            alert('공백 입력 금지!');
        }else{
            let body = { issue_author: name.current.value, issue_title: title.current.value, issue_details: details.current.value, issue_project_no: no.current.value, issue_label: label}
            axios.post('http://localhost:8080/spring/companyBoard/issueWrite', body)
                .then(() => {
                    page('Issue',pjNo);
                })
                .catch(error => {
                    console.error('에러!', error);
                })
        }
    }

    return (
        <div id='issue_write_page'>
            <div id='write_box'>
                <form id='form_box' onSubmit={axiosIssueWrite}>
                    <input ref={id} type='hidden' value={loginId}></input>
                    <input ref={name} type='hidden' value={loginName}></input>
                    <input ref={no} type='hidden' value={pjNo}></input>
                    <input style={{width: '1000px', height: '50px'}} ref={title} placeholder='Add a title'></input> <br/><br/>
                    label:<select value='select a label' onChange={(e) => setLabel(e.target.value)}>
                        <option key='0' value='bug'>bug</option>
                        <option key='1' value='documentation'>documentation</option>
                        <option key='2' value='duplicate'>duplicate</option>
                    </select>
                    <textarea style={{width: '1000px', height: '500px'}} ref={details} placeholder='Add a description'></textarea> <br/><br/>
                    <button type='submit'>등록</button> &nbsp;
                    <button onClick={() => page('Issue',pjNo)}>취소</button>
                </form>
            </div>
        </div>
    );
}

export default IssueWrite;