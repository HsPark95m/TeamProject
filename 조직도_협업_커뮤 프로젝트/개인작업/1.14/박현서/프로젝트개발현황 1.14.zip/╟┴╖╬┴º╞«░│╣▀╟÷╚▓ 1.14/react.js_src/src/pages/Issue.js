import { useEffect, useState } from 'react';
import './Board.css';
import axios from 'axios';

function Issue({ page, pjNo }) {   

    const [Issues, setIssues] = useState([]);

    useEffect(() => {
        axiosGetIssueList();
    }, []);

    function axiosGetIssueList() {
        axios.get(`http://localhost:8080/spring/companyBoard/getPostList?pjNo=${pjNo}`)
            .then((response) => {
                setIssues(response.data);
            })
            .catch(error => {
                console.error('에러!', error);
            })
    }

    return (
        <div id='board_get_list_page'>
            <div id='list_box'>
                <h3>이슈 리스트</h3>
                <table style={{ width: '1270px' }}>
                    <tbody>
                        <tr>
                            <td style={{ width: '10%', height: '30px' }}>글번호</td>
                            <td style={{ width: '55%' }}>글제목</td>
                            <td style={{ width: '15%' }}>작성자</td>
                            <td style={{ width: '15%' }}>작성일</td>
                            <td style={{ width: '5%' }}>조회수</td>
                        </tr>
                        {currentPosts.map((p, i) =>
                            <tr key={i}>
                                <td style={{ width: '10%', height: '30px' }}>{p.cb_no}</td>
                                <td id='post_title_link' style={{ width: '55%' }} onClick={() => read(p.cb_no)}>{p.cb_title}</td>
                                <td style={{ width: '15%' }}>{p.company_name}</td>
                                <td style={{ width: '15%' }}>{p.formattedDate}</td>
                                <td style={{ width: '5%' }}>{p.cb_hits}</td>
                            </tr>
                        )}
                    </tbody>
                </table>
                <hr />

                <hr />
                <button id='main_button' onClick={() => page('board')}>메인으로</button>
                <button id='main_button' onClick={() => page('board_write')}>글쓰기</button>
                <hr />
                <select onChange={(e) => setSearchTag(e.target.value)}>
                    <option value='cb_title'>글제목</option>
                    <option value='cb_text'>글내용</option>
                    <option value='company_name'>작성자</option>
                </select>
                <form onSubmit={search}>
                    <input value={searchWord} onChange={(e) => setSearchWord(e.target.value)} placeholder='검색어를 입력 해주세요'></input>
                    <button type='submit'>검색</button>
                </form>
            </div>
        </div>
    );
}

export default Issue;