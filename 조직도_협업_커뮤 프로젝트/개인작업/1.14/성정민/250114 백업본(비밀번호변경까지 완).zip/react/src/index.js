import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import LoginPage from './pages/LoginPage';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Mypage from './pages/Mypage';
import ModifyInfo from './pages/ModifyInfo';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path='/' element={<App/>}/>
        <Route path='/login' element={<LoginPage/>}/>
        <Route path='/mypage' element={<Mypage/>}/>
        <Route path='/mypage/modifyInfo' element={<ModifyInfo/>}></Route>
      </Routes>
    </BrowserRouter>
  </React.StrictMode>
);