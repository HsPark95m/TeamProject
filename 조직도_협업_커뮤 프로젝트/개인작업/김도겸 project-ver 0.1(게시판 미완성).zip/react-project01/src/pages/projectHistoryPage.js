function ProjectHistoryPage(){
    return(
        <div style={{backgroundColor : "white", width : "1359px"}}>
            <h1>프로젝트 연혁</h1>
            <ol>
                <li>2024년 12월 12일 뭐했음</li>
                <br/>
                <li>2024년 12월 13일 뭔가했음</li>
                <br/>
                <li>2024년 12월 14일 뭐했노</li>
                <br/>
                <li>2024년 12월 15일 뭐</li>
                <br/>
            </ol>
        </div>
    );
}

export default ProjectHistoryPage;