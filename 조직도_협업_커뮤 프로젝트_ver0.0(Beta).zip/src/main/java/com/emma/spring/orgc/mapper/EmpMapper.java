package com.emma.spring.orgc.mapper;

import java.util.ArrayList;

import com.emma.spring.orgc.dto.EmpDto;

public interface EmpMapper {
	public ArrayList<EmpDto> getEmp();

	public int divCount();
}
