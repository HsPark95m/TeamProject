package com.emma.spring.orgc.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emma.spring.orgc.dto.EmpDto;
import com.emma.spring.orgc.mapper.EmpMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class EmpServieImpl implements EmpService {
	@Setter(onMethod_ = @Autowired)
	private EmpMapper mapper;

	@Override
	public ArrayList<EmpDto> getEmp() {
		return mapper.getEmp();
	}

	@Override
	public int divCount() {
		return mapper.divCount();
	}
}
