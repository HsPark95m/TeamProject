package com.emma.spring.orgc.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.emma.spring.orgc.dto.CoPjDto;
import com.emma.spring.orgc.dto.MemberAddDto;
import com.emma.spring.orgc.service.CoPjService;

import lombok.Setter;

@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/copj/*")
@RestController
public class CoPjController {
	@Setter(onMethod_ = @Autowired)
	private CoPjService service;

	@RequestMapping("/getCoPj")
	public ArrayList<CoPjDto> getCoPj() {
		return service.getCoPj();
	}

	@RequestMapping("/closeCoPj")
	public void closeCoPj(@RequestParam("pjNo") long pjNo) {
		service.closeCoPj(pjNo);
	}

	@RequestMapping("/pjMemberAdd")
	public void pjMemberAdd(@RequestBody MemberAddDto m) {
		service.pjMemberAdd(m);
	}

	@RequestMapping("/getCoPjMember")
	public ArrayList<MemberAddDto> getCoPjMember() {
		return service.getCoPjMember();
	}
}
