use my_cat;

show tables;

drop table Employee;
create table Employee(
	Emp_no int primary key,
    Emp_name char(10) not null default '사원테스트',
    Emp_dep char(10) not null default '부서테스트',
    Emp_position char(10) not null default '사원',
    Emp_rank int not null default 1
);
INSERT INTO Employee (`Emp_no`,`Emp_name`,`Emp_dep`,`Emp_position`,`Emp_rank`) VALUES (0,'나사장','이사회','사장',0);
INSERT INTO Employee (`Emp_no`,`Emp_name`,`Emp_dep`,`Emp_position`,`Emp_rank`) VALUES (1,'나부장','게임개발부','부장',1);
INSERT INTO Employee (`Emp_no`,`Emp_name`,`Emp_dep`,`Emp_position`,`Emp_rank`) VALUES (2,'나사원','게임개발부','사원',2);
INSERT INTO Employee (`Emp_no`,`Emp_name`,`Emp_dep`,`Emp_position`,`Emp_rank`) VALUES (3,'김부장','경영지원부','부장',1);
INSERT INTO Employee (`Emp_no`,`Emp_name`,`Emp_dep`,`Emp_position`,`Emp_rank`) VALUES (4,'김사원','경영지원부','사원',2);
INSERT INTO Employee (`Emp_no`,`Emp_name`,`Emp_dep`,`Emp_position`,`Emp_rank`) VALUES (5,'최사원','경영지원부','사원',2);
INSERT INTO Employee (`Emp_no`,`Emp_name`,`Emp_dep`,`Emp_position`,`Emp_rank`) VALUES (6,'박사원','경영지원부','사원',2);
INSERT INTO Employee (`Emp_no`,`Emp_name`,`Emp_dep`,`Emp_position`,`Emp_rank`) VALUES (7,'이부장','영업부','부장',1);
INSERT INTO Employee (`Emp_no`,`Emp_name`,`Emp_dep`,`Emp_position`,`Emp_rank`) VALUES (8,'이사원','영업부','사원',2);
-- ALTER TABLE Employee DROP COLUMN Emp_participate;

select * from Employee;
SELECT * from Employee ORDER BY Emp_rank;

drop table Cooperation_Project;
create table Cooperation_Project(
	Coop_no int primary key,
	Coop_name char(20) not null default '무제',
    Coop_content char(255) not null default '설명란',
    Coop_importance int not null default 1
);
INSERT INTO Cooperation_Project (`Coop_no`, `Coop_name`) VALUES (1, '무제1');
INSERT INTO Cooperation_Project (`Coop_no`, `Coop_name`) VALUES (2, '무제2');
INSERT INTO Cooperation_Project (`Coop_no`, `Coop_name`) VALUES (3, '무제3');
select * from Cooperation_Project;

drop table Project_Management;
create table Project_Management(
	Emp_no int not null,
    Coop_no int not null
);
select * from Project_Management;